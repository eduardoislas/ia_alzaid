(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-posts-posts-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/posts/posts.page.html":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/posts/posts.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesPostsPostsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-header titulo=\"Publicaciones\"></app-header>\n\n<ion-content>\n\n    <!-- Post card -->\n    <ion-card class=\"post-card\">\n        <ion-item lines=\"none\" class=\"post-item\">\n            <ion-avatar slot=\"start\">\n                <img src=\"../../assets/avatars/av-1.png\">\n            </ion-avatar>\n            <ion-input placeholder=\"Comparte algo...\"></ion-input>\n            <ion-buttons slot=\"end\">\n                <ion-button color=\"medium\">\n                    <ion-icon slot=\"icon-only\" name=\"image\"></ion-icon>\n                </ion-button>\n                <ion-button color=\"medium\">\n                    <ion-icon slot=\"icon-only\" name=\"document-text\"></ion-icon>\n                </ion-button>\n            </ion-buttons>\n\n        </ion-item>\n        <ion-button color=\"primary\" size=\"small\" shape=\"round\" expand=\"block\">\n            Compartir\n        </ion-button>\n    </ion-card>\n\n\n    <ng-container>\n        <ion-card class=\"post-list-card\" *ngFor=\"let post of posts\">\n            <ion-item lines=\"none\">\n                <ion-avatar slot=\"start\">\n                    <img [src]=\"post.image\">\n                </ion-avatar>\n                <ion-label>\n                    {{post.name}}\n                    <p>Hace {{post.time}}</p>\n                </ion-label>\n                <ion-buttons slot=\"end\">\n                    <ion-button color=\"medium\">\n                        <ion-icon slot=\"icon-only\" md=\"ellipsis-vertical-outline\" ios=\"ellipsis-horizontal-outline\"></ion-icon>\n                    </ion-button>\n                </ion-buttons>\n            </ion-item>\n\n            <ion-card-content class=\"post-list-content\">\n                {{post.content}}\n            </ion-card-content>\n\n            <ion-item lines=\"none\" class=\"action-item\">\n                <ion-buttons slot=\"start\">\n                    <ion-button color=\"medium\" class=\"action-button\">\n                        <ion-icon slot=\"start\" name=\"heart-outline\"></ion-icon>\n                        {{post.likes}}\n                    </ion-button>\n                    <ion-button color=\"medium\" class=\"action-button\">\n                        <ion-icon slot=\"start\" name=\"chatbox-outline\"></ion-icon>\n                        {{post.comments}}\n                    </ion-button>\n                    <ion-button color=\"medium\" class=\"action-button\">\n                        <ion-icon slot=\"start\" name=\"return-up-forward-outline\"></ion-icon>\n                        {{post.shared}}\n                    </ion-button>\n                </ion-buttons>\n\n                <ion-buttons slot=\"end\">\n                    <ion-button color=\"medium\">\n                        <ion-icon size=\"small\" slot=\"start\" name=\"eye-outline\"></ion-icon>\n                        6\n                    </ion-button>\n                </ion-buttons>\n            </ion-item>\n        </ion-card>\n    </ng-container>\n\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/posts/posts-routing.module.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/posts/posts-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: PostsPageRoutingModule */

    /***/
    function srcAppPagesPostsPostsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostsPageRoutingModule", function () {
        return PostsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _posts_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./posts.page */
      "./src/app/pages/posts/posts.page.ts");

      var routes = [{
        path: '',
        component: _posts_page__WEBPACK_IMPORTED_MODULE_3__["PostsPage"]
      }];

      var PostsPageRoutingModule = function PostsPageRoutingModule() {
        _classCallCheck(this, PostsPageRoutingModule);
      };

      PostsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PostsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/posts/posts.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/pages/posts/posts.module.ts ***!
      \*********************************************/

    /*! exports provided: PostsPageModule */

    /***/
    function srcAppPagesPostsPostsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostsPageModule", function () {
        return PostsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _posts_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./posts-routing.module */
      "./src/app/pages/posts/posts-routing.module.ts");
      /* harmony import */


      var _posts_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./posts.page */
      "./src/app/pages/posts/posts.page.ts");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components/components.module */
      "./src/app/components/components.module.ts");

      var PostsPageModule = function PostsPageModule() {
        _classCallCheck(this, PostsPageModule);
      };

      PostsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _posts_routing_module__WEBPACK_IMPORTED_MODULE_5__["PostsPageRoutingModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
        declarations: [_posts_page__WEBPACK_IMPORTED_MODULE_6__["PostsPage"]]
      })], PostsPageModule);
      /***/
    },

    /***/
    "./src/app/pages/posts/posts.page.scss":
    /*!*********************************************!*\
      !*** ./src/app/pages/posts/posts.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesPostsPostsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Bvc3RzL3Bvc3RzLnBhZ2Uuc2NzcyJ9 */";
      /***/
    },

    /***/
    "./src/app/pages/posts/posts.page.ts":
    /*!*******************************************!*\
      !*** ./src/app/pages/posts/posts.page.ts ***!
      \*******************************************/

    /*! exports provided: PostsPage */

    /***/
    function srcAppPagesPostsPostsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostsPage", function () {
        return PostsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var PostsPage = /*#__PURE__*/function () {
        function PostsPage() {
          _classCallCheck(this, PostsPage);

          this.posts = [{
            name: 'María de los ángeles Gómez',
            image: '../../assets/avatars/av-3.png',
            content: 'Desde hace más de tres años, trabajo con personas dementes. He aprendido a sumergirme en su mundo y a vivir con ellos durante un período de tiempo, y a veces es duro y doloroso, pero también divertido en otras ocasiones. A veces ocurre que te atraen su desesperanza, su miedo, y con todo esto te estas enfrentando a tus propios temores. He aprendido a no asumir este temor a la hora de volver a casa. He aprendido también que la sola idea de no poder quitarse la ropa por la noche, que otra persona la puso por la mañana, puede estropear el día, porque no se acuerdan de que habrá alguien para ayudarles por la noche. He visto lo desconcertante que puede ser, que todo lo que el cerebro ha almacenado durante años, se pierda de repente, todo se vuelva un lío sin lógica, sin sentido.',
            likes: 50,
            comments: 12,
            shared: 2,
            views: 72,
            time: "un minuto"
          }, {
            name: 'Eduardo Islas',
            image: '../../assets/avatars/av-1.png',
            content: 'Los primeros signos y síntomas de demencia de Alzheimer: Deterioro de la memoria, como por ejemplo, dificultad para recordar eventos, Dificultad para concentrarse, planificar o resolver problemas, Problemas para completar tareas diarias en el hogar o en el trabajo, Confusión con respecto a los lugares o el paso del tiempo.',
            likes: 102,
            comments: 23,
            shared: 12,
            views: 120,
            time: "tres minutos"
          }, {
            name: 'Guadalupe Contreras',
            image: '../../assets/avatars/av-5.png',
            content: 'Mi nombre es Guadalupe y mi marido se llama Antonio. El empezó con esa enfermedad con 52 años. Teníamos un negocio y yo estaba siempre con él. Me fui dando cuenta poco a poco de la enfermedad, yo no sabía nada de ella, pero vi que le pasaba algo raro: contaba a la gente cosas de sitios que habíamos estado que jamás en la vida habíamos ido, escondía las cosas y decía que se las habíamos escondido nosotros o mis hijos, cosa que tampoco ocurría porque mis hijos son muy formales, y él igual, mi marido era una persona muy correcta, muy educada, extraordinario.',
            likes: 122,
            comments: 45,
            shared: 18,
            views: 180,
            time: "cinco minutos"
          }, {
            name: 'Mariana Mizraji',
            image: '../../assets/avatars/av-7.png',
            content: 'Hola, soy Mariana (46), hace un año le diagnos­ticaron Alzheimer a mi papá (82). Hace un tiempo mi papá tiene un apellido nuevo, y no tiene nada que ver con un segundo matrimonio, sino a otro agregado que se sumó sin que lo llamen: Luis Mizraji "Alzheimer".',
            likes: 13,
            comments: 3,
            shared: 2,
            views: 25,
            time: "diez minutos"
          }, {
            name: 'Juan Navarro',
            image: '../../assets/avatars/av-6.png',
            content: 'Estar en el grupo de ayuda de la estancia Alzheimer, me ayudó a sobrellevar la enfermedad de otra manera. Fue un aprendizaje permanente. El cuidado de mamá pasó a ser el eje de nuestras vidas. A partir también de una decisión tomada ella permanecería siempre en su casa, con sus cosas personales, cerca del afecto de la familia y la compañía de su gata siamesa. Si teníamos compromisos laborales o personales, dependíamos de coordinarlos con su cuidado.',
            likes: 85,
            comments: 30,
            shared: 9,
            views: 135,
            time: "45 minutos"
          }];
        }

        _createClass(PostsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PostsPage;
      }();

      PostsPage.ctorParameters = function () {
        return [];
      };

      PostsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-posts',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./posts.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/posts/posts.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./posts.page.scss */
        "./src/app/pages/posts/posts.page.scss"))["default"]]
      })], PostsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-posts-posts-module-es5.js.map