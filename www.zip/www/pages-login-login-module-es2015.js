(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <ion-slides class=\"mainSlide\" #slidePrincipal>\n\n        <ion-slide>\n            <form (ngSubmit)=\"begin( fBegin )\" #fBegin=\"ngForm\">\n                <ion-row class=\"vertical-center\">\n\n                    <div class=\"center\">\n                        <ion-img style=\"width: 200px; height: 200px;\" src=\"../../assets/img/logo.png\"></ion-img>\n                    </div>\n\n                </ion-row>\n\n\n                <ion-grid fixed>\n                    <ion-row>\n                        <ion-col>\n                            <ion-list>\n                                <ion-item>\n                                    <ion-label class=\"titulo\">Bienvenido</ion-label>\n\n                                </ion-item>\n                                <ion-item>\n                                    <ion-textarea class=\"texto\">Nuestro Asistente Inteligente Alzaid formará parte de tu red de apoyo para resolver tus dudas sobre la enfermedad de Alzheimer, y si le cuentas un poco sobre tu ser amado con esta enfermedad, te ayudará con la adecuación\n                                        de actividades, dietas, entre otras cosas. </ion-textarea>\n                                </ion-item>\n                            </ion-list>\n                        </ion-col>\n                    </ion-row>\n                    <ion-row>\n                        <ion-col>\n                            <ion-button type=\"submit\" color=\"primary\" shape=\"round\">\n                                Comenzar\n                            </ion-button>\n                        </ion-col>\n                    </ion-row>\n                </ion-grid>\n            </form>\n        </ion-slide>\n\n        <ion-slide>\n            <form (ngSubmit)=\"login( fLogin )\" #fLogin=\"ngForm\">\n                <ion-grid fixed>\n\n                    <ion-row>\n                        <ion-col>\n                            <img src=\"/assets/avatars/av-1.png\">\n                        </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                        <ion-col>\n\n                            <ion-list>\n\n                                <ion-item>\n                                    <!-- <ion-label>Correo electrónico</ion-label> -->\n                                    <ion-input placeholder=\"Correo electrónico\" name=\"email\" type=\"email\"></ion-input>\n                                </ion-item>\n\n                                <ion-item>\n                                    <!-- <ion-label>Contraseña</ion-label> -->\n                                    <ion-input placeholder=\"Contraseña\" name=\"password\" type=\"password\"></ion-input>\n                                </ion-item>\n\n                            </ion-list>\n                        </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                        <ion-col>\n                            <ion-button type=\"submit\" color=\"primary\" shape=\"round\">\n                                Iniciar sesión\n                            </ion-button>\n                        </ion-col>\n                    </ion-row>\n\n                </ion-grid>\n            </form>\n\n\n        </ion-slide>\n\n        <ion-slide>\n\n            <ion-grid fixed>\n\n                <ion-row>\n                    <ion-col>\n                        <h3>Seleccione Avatar</h3>\n                    </ion-col>\n                </ion-row>\n\n                <ion-row>\n                    <ion-col>\n                        <ion-slides [options]=\"avatarSlide \">\n                            <ion-slide *ngFor=\"let avatar of avatars \">\n                                <ion-img class=\"pick-avatar\" src=\"/assets/avatars/{{avatar.img}}\" [ngClass]=\"{ 'pick-avatar-seleccionado': avatar.seleccionado } \" (click)=\"seleccionarAvatar( avatar ) \"></ion-img>\n                            </ion-slide>\n                        </ion-slides>\n                    </ion-col>\n                </ion-row>\n\n                <form (ngSubmit)=\"register( fRegister )\" #fRegister=\"ngForm\">\n                    <ion-row>\n                        <ion-col>\n\n                            <ion-list>\n\n                                <ion-item>\n                                    <!-- <ion-label>Correo electrónico</ion-label> -->\n                                    <ion-input placeholder=\"Correo electrónico\" name=\"email\" type=\"email\" required></ion-input>\n                                </ion-item>\n\n                                <ion-item>\n                                    <!-- <ion-label>Nombre</ion-label> -->\n                                    <ion-input placeholder=\"Nombre\" name=\"name\" type=\"text\" required></ion-input>\n                                </ion-item>\n\n                                <ion-item>\n                                    <!-- <ion-label>Contraseña</ion-label> -->\n                                    <ion-input placeholder=\"Contraseña\" name=\"password\" type=\"password\" required></ion-input>\n                                </ion-item>\n\n                            </ion-list>\n                        </ion-col>\n                    </ion-row>\n\n                    <ion-row>\n                        <ion-col>\n                            <ion-button type=\"submit\" color=\"primary\" shape=\"round\">\n                                Crear usuario\n                            </ion-button>\n                        </ion-col>\n                    </ion-row>\n\n                </form>\n            </ion-grid>\n\n        </ion-slide>\n    </ion-slides>\n</ion-content>\n\n<ion-footer no-border>\n    <ion-toolbar>\n        <ion-row>\n            <ion-col>\n                <ion-button type=\"submit\" color=\"danger\" shape=\"round\" expand=\"full\" size=\"small\" (click)=\"loginGoogle()\">\n                    <ion-icon name=\"logo-google\"> </ion-icon>\n                    Iniciar con Google\n                </ion-button>\n            </ion-col>\n        </ion-row>\n\n        <ion-row>\n\n            <ion-col>\n                <ion-button shape=\"round\" expand=\"full\" size=\"small\" fill=\"outline\" color=\"primary\" (click)=\"mostrarLogin()\">\n                    Ingresar\n                </ion-button>\n            </ion-col>\n\n            <ion-col>\n                <ion-button shape=\"round\" expand=\"full\" size=\"small\" fill=\"outline\" color=\"primary\" (click)=\"mostrarRegistro()\">\n                    Registrarme\n                </ion-button>\n            </ion-col>\n\n        </ion-row>\n\n    </ion-toolbar>\n</ion-footer>");

/***/ }),

/***/ "./src/app/pages/login/login-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/login/login-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "./src/app/pages/login/login.page.ts");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/login/login.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "./src/app/pages/login/login-routing.module.ts");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/pages/login/login.page.ts");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/pages/login/login.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".mainSlide,\n.mainSlide ion-slide {\n  width: 100%;\n  height: 100%;\n}\n\nimg {\n  width: 120px;\n}\n\n.pick-avatar {\n  width: 80px;\n  opacity: 0.3;\n}\n\n.pick-avatar-seleccionado {\n  transition: opacity 0.5s linear;\n  opacity: 1 !important;\n}\n\n.titulo {\n  font-size: 22pt;\n  text-align: center;\n}\n\n.texto {\n  text-align: justify;\n  list-style: none;\n  border: 0%;\n}\n\n#container {\n  text-align: center;\n  position: fixed;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n.vertical-center {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVJLFdBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0ksK0JBQUE7RUFDQSxxQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtBQUNKOztBQUVBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW5TbGlkZSxcclxuLm1haW5TbGlkZSBpb24tc2xpZGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbmltZyB7XHJcbiAgICB3aWR0aDogMTIwcHg7XHJcbn1cclxuXHJcbi5waWNrLWF2YXRhciB7XHJcbiAgICB3aWR0aDogODBweDtcclxuICAgIG9wYWNpdHk6IDAuMztcclxufVxyXG5cclxuLnBpY2stYXZhdGFyLXNlbGVjY2lvbmFkbyB7XHJcbiAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuNXMgbGluZWFyO1xyXG4gICAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGl0dWxvIHtcclxuICAgIGZvbnQtc2l6ZTogMjJwdDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnRleHRvIHtcclxuICAgIHRleHQtYWxpZ246IGp1c3RpZnk7XHJcbiAgICBsaXN0LXN0eWxlOiBub25lO1xyXG4gICAgYm9yZGVyOiAwJTtcclxufVxyXG5cclxuI2NvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxufVxyXG5cclxuLnZlcnRpY2FsLWNlbnRlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG59Il19 */");

/***/ }),

/***/ "./src/app/pages/login/login.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-auth.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.esm.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! sweetalert2 */ "./node_modules/sweetalert2/dist/sweetalert2.all.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _models_user_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../models/user.model */ "./src/app/models/user.model.ts");
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/data.service */ "./src/app/services/data.service.ts");











let LoginPage = class LoginPage {
    constructor(menu, router, afAuth, platform, googlePlus, data) {
        this.menu = menu;
        this.router = router;
        this.afAuth = afAuth;
        this.platform = platform;
        this.googlePlus = googlePlus;
        this.data = data;
        this.avatars = [
            {
                img: 'av-1.png',
                seleccionado: true
            },
            {
                img: 'av-2.png',
                seleccionado: false
            },
            {
                img: 'av-3.png',
                seleccionado: false
            },
            {
                img: 'av-4.png',
                seleccionado: false
            },
            {
                img: 'av-5.png',
                seleccionado: false
            },
            {
                img: 'av-6.png',
                seleccionado: false
            },
            {
                img: 'av-7.png',
                seleccionado: false
            },
            {
                img: 'av-8.png',
                seleccionado: false
            },
        ];
        this.avatarSlide = {
            slidesPerView: 3.5
        };
        //For google login
        // picture;
        // name;
        // email;
        this.user = new _models_user_model__WEBPACK_IMPORTED_MODULE_8__["User"]();
        this.menu.enable(false, 'first');
    }
    ngOnInit() {
        //this.slides.lockSwipes(true);
        this.menu.enable(false, 'first');
    }
    login(fLogin) {
        if (fLogin.valid) {
            this.disparaAlerta(true);
        }
        else {
            this.disparaAlerta(false);
        }
    }
    loginGoogle() {
        if (this.platform.is('android')) {
            this.loginGoogleAndroid();
        }
        else {
            this.loginGoogleWeb();
            // this.loginGoogleAndroid();
        }
    }
    loginGoogleAndroid() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield this.googlePlus.login({
                'webClientId': "885861179919-afmh5u02ou6tbkgf8e59kicstj9fulmi.apps.googleusercontent.com",
                'offline': true
            });
            const resConfirmed = yield this.afAuth.signInWithCredential(firebase_app__WEBPACK_IMPORTED_MODULE_3__["default"].auth.GoogleAuthProvider.credential(res.idToken));
            const user = resConfirmed.user;
            // this.picture = user.photoURL;
            // this.name = user.displayName;
            // this.email = user.email;
            this.cargarDatos(user);
        });
    }
    loginGoogleWeb() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const res = yield this.afAuth.signInWithPopup(new firebase_app__WEBPACK_IMPORTED_MODULE_3__["default"].auth.GoogleAuthProvider());
            const user = res.user;
            //console.log(user);
            // this.picture = user.photoURL;
            // this.name = user.displayName;
            // this.email = user.email;
            // this.cargarDatos(user);
            this.user = new _models_user_model__WEBPACK_IMPORTED_MODULE_8__["User"]();
            console.log(user);
            this.data.saveUser(this.user);
            this.disparaAlerta(true);
        });
    }
    cargarDatos(user) {
        // if(!user){
        //   this.user.name = user.displayName;
        //   this.user.email = user.email;
        //   this.user.picture = user.photoURL;
        //   this.user.isGoogle = user.emailVerified;
        // }else{
        //   this.user = new User();
        // }
        this.user.name = user.displayName;
        this.user.email = user.email;
        this.user.picture = user.photoURL;
        this.user.isGoogle = user.emailVerified;
        console.log(this.user);
        this.data.saveUser(this.user);
        this.disparaAlerta(this.user.isGoogle);
    }
    register(fRegister) {
        console.log(fRegister.valid);
    }
    begin(fBegin) {
        this.slides.lockSwipes(false);
        this.slides.slideTo(1);
        this.slides.lockSwipes(true);
    }
    seleccionarAvatar(avatar) {
        this.avatars.forEach(av => av.seleccionado = false);
        avatar.seleccionado = true;
    }
    mostrarRegistro() {
        this.slides.lockSwipes(false);
        this.slides.slideTo(2);
        this.slides.lockSwipes(true);
    }
    mostrarLogin() {
        this.slides.lockSwipes(false);
        this.slides.slideTo(1);
        this.slides.lockSwipes(true);
    }
    // login( email: string, password: string ) {
    //   if(email == "" && password == ""){
    //     this.disparaAlerta(true);
    //   }else{
    //     this.disparaAlerta(false);
    //   }
    // }
    disparaAlerta(success) {
        if (success) {
            this.router.navigateByUrl('/home');
        }
        else {
            sweetalert2__WEBPACK_IMPORTED_MODULE_7___default.a.fire({
                icon: 'error',
                title: 'Verificar sus datos',
                showConfirmButton: false,
                timer: 1500
            });
        }
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__["AngularFireAuth"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_5__["GooglePlus"] },
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_9__["DataService"] }
];
LoginPage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"], args: ['slidePrincipal',] }]
};
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login.page.scss */ "./src/app/pages/login/login.page.scss")).default]
    })
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=pages-login-login-module-es2015.js.map