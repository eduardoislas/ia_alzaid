(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"],{

/***/ "./node_modules/api-ai-javascript/es6/ApiAiClient.js":
/*!***********************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/ApiAiClient.js ***!
  \***********************************************************/
/*! exports provided: IStreamClient, ApiAiConstants, ApiAiClient */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiAiClient", function() { return ApiAiClient; });
/* harmony import */ var _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ApiAiConstants */ "./node_modules/api-ai-javascript/es6/ApiAiConstants.js");
/* harmony import */ var _Errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Errors */ "./node_modules/api-ai-javascript/es6/Errors.js");
/* harmony import */ var _Request_EventRequest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Request/EventRequest */ "./node_modules/api-ai-javascript/es6/Request/EventRequest.js");
/* harmony import */ var _Request_TextRequest__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Request/TextRequest */ "./node_modules/api-ai-javascript/es6/Request/TextRequest.js");
/* harmony import */ var _Interfaces__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Interfaces */ "./node_modules/api-ai-javascript/es6/Interfaces.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "IStreamClient", function() { return _Interfaces__WEBPACK_IMPORTED_MODULE_4__["IStreamClient"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ApiAiConstants", function() { return _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"]; });







class ApiAiClient {
    constructor(options) {
        if (!options || !options.accessToken) {
            throw new _Errors__WEBPACK_IMPORTED_MODULE_1__["ApiAiClientConfigurationError"]("Access token is required for new ApiAi.Client instance");
        }
        this.accessToken = options.accessToken;
        this.apiLang = options.lang || _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_CLIENT_LANG;
        this.apiVersion = options.version || _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_API_VERSION;
        this.apiBaseUrl = options.baseUrl || _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_BASE_URL;
        this.sessionId = options.sessionId || this.guid();
    }
    textRequest(query, options = {}) {
        if (!query) {
            throw new _Errors__WEBPACK_IMPORTED_MODULE_1__["ApiAiClientConfigurationError"]("Query should not be empty");
        }
        options.query = query;
        return new _Request_TextRequest__WEBPACK_IMPORTED_MODULE_3__["default"](this, options).perform();
    }
    eventRequest(eventName, eventData = {}, options = {}) {
        if (!eventName) {
            throw new _Errors__WEBPACK_IMPORTED_MODULE_1__["ApiAiClientConfigurationError"]("Event name can not be empty");
        }
        options.event = { name: eventName, data: eventData };
        return new _Request_EventRequest__WEBPACK_IMPORTED_MODULE_2__["EventRequest"](this, options).perform();
    }
    // @todo: implement local tts request
    /*public ttsRequest(query) {
        if (!query) {
            throw new ApiAiClientConfigurationError("Query should not be empty");
        }
        return new TTSRequest(this).makeTTSRequest(query);
    }*/
    /*public userEntitiesRequest(options: IRequestOptions = {}): UserEntitiesRequest {
        return new UserEntitiesRequest(this, options);
    }*/
    getAccessToken() {
        return this.accessToken;
    }
    getApiVersion() {
        return (this.apiVersion) ? this.apiVersion : _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_API_VERSION;
    }
    getApiLang() {
        return (this.apiLang) ? this.apiLang : _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_CLIENT_LANG;
    }
    getApiBaseUrl() {
        return (this.apiBaseUrl) ? this.apiBaseUrl : _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_BASE_URL;
    }
    setSessionId(sessionId) {
        this.sessionId = sessionId;
    }
    getSessionId() {
        return this.sessionId;
    }
    /**
     * generates new random UUID
     * @returns {string}
     */
    guid() {
        const s4 = () => Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        return s4() + s4() + "-" + s4() + "-" + s4() + "-" +
            s4() + "-" + s4() + s4() + s4();
    }
}


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/ApiAiConstants.js":
/*!**************************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/ApiAiConstants.js ***!
  \**************************************************************/
/*! exports provided: ApiAiConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiAiConstants", function() { return ApiAiConstants; });
var ApiAiConstants;
(function (ApiAiConstants) {
    let AVAILABLE_LANGUAGES;
    (function (AVAILABLE_LANGUAGES) {
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["EN"] = "en"] = "EN";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["DE"] = "de"] = "DE";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ES"] = "es"] = "ES";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["PT_BR"] = "pt-BR"] = "PT_BR";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_HK"] = "zh-HK"] = "ZH_HK";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_CN"] = "zh-CN"] = "ZH_CN";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_TW"] = "zh-TW"] = "ZH_TW";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["NL"] = "nl"] = "NL";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["FR"] = "fr"] = "FR";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["IT"] = "it"] = "IT";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["JA"] = "ja"] = "JA";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["KO"] = "ko"] = "KO";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["PT"] = "pt"] = "PT";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["RU"] = "ru"] = "RU";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["UK"] = "uk"] = "UK";
    })(AVAILABLE_LANGUAGES = ApiAiConstants.AVAILABLE_LANGUAGES || (ApiAiConstants.AVAILABLE_LANGUAGES = {}));
    ApiAiConstants.VERSION = "2.0.0-beta.20";
    ApiAiConstants.DEFAULT_BASE_URL = "https://api.api.ai/v1/";
    ApiAiConstants.DEFAULT_API_VERSION = "20150910";
    ApiAiConstants.DEFAULT_CLIENT_LANG = AVAILABLE_LANGUAGES.EN;
})(ApiAiConstants || (ApiAiConstants = {}));


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/Errors.js":
/*!******************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/Errors.js ***!
  \******************************************************/
/*! exports provided: ApiAiBaseError, ApiAiClientConfigurationError, ApiAiRequestError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiAiBaseError", function() { return ApiAiBaseError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiAiClientConfigurationError", function() { return ApiAiClientConfigurationError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiAiRequestError", function() { return ApiAiRequestError; });
class ApiAiBaseError extends Error {
    constructor(message) {
        super(message);
        this.message = message;
        this.stack = new Error().stack;
    }
}
class ApiAiClientConfigurationError extends ApiAiBaseError {
    constructor(message) {
        super(message);
        this.name = "ApiAiClientConfigurationError";
    }
}
class ApiAiRequestError extends ApiAiBaseError {
    constructor(message, code = null) {
        super(message);
        this.message = message;
        this.code = code;
        this.name = "ApiAiRequestError";
    }
}


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/Interfaces.js":
/*!**********************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/Interfaces.js ***!
  \**********************************************************/
/*! exports provided: IStreamClient */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IStreamClient", function() { return IStreamClient; });
var IStreamClient;
(function (IStreamClient) {
    let ERROR;
    (function (ERROR) {
        ERROR[ERROR["ERR_NETWORK"] = 0] = "ERR_NETWORK";
        ERROR[ERROR["ERR_AUDIO"] = 1] = "ERR_AUDIO";
        ERROR[ERROR["ERR_SERVER"] = 2] = "ERR_SERVER";
        ERROR[ERROR["ERR_CLIENT"] = 3] = "ERR_CLIENT";
    })(ERROR = IStreamClient.ERROR || (IStreamClient.ERROR = {}));
    let EVENT;
    (function (EVENT) {
        EVENT[EVENT["MSG_WAITING_MICROPHONE"] = 0] = "MSG_WAITING_MICROPHONE";
        EVENT[EVENT["MSG_MEDIA_STREAM_CREATED"] = 1] = "MSG_MEDIA_STREAM_CREATED";
        EVENT[EVENT["MSG_INIT_RECORDER"] = 2] = "MSG_INIT_RECORDER";
        EVENT[EVENT["MSG_RECORDING"] = 3] = "MSG_RECORDING";
        EVENT[EVENT["MSG_SEND"] = 4] = "MSG_SEND";
        EVENT[EVENT["MSG_SEND_EMPTY"] = 5] = "MSG_SEND_EMPTY";
        EVENT[EVENT["MSG_SEND_EOS_OR_JSON"] = 6] = "MSG_SEND_EOS_OR_JSON";
        EVENT[EVENT["MSG_WEB_SOCKET"] = 7] = "MSG_WEB_SOCKET";
        EVENT[EVENT["MSG_WEB_SOCKET_OPEN"] = 8] = "MSG_WEB_SOCKET_OPEN";
        EVENT[EVENT["MSG_WEB_SOCKET_CLOSE"] = 9] = "MSG_WEB_SOCKET_CLOSE";
        EVENT[EVENT["MSG_STOP"] = 10] = "MSG_STOP";
        EVENT[EVENT["MSG_CONFIG_CHANGED"] = 11] = "MSG_CONFIG_CHANGED";
    })(EVENT = IStreamClient.EVENT || (IStreamClient.EVENT = {}));
})(IStreamClient || (IStreamClient = {}));


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/Request/EventRequest.js":
/*!********************************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/Request/EventRequest.js ***!
  \********************************************************************/
/*! exports provided: EventRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventRequest", function() { return EventRequest; });
/* harmony import */ var _Request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Request */ "./node_modules/api-ai-javascript/es6/Request/Request.js");

class EventRequest extends _Request__WEBPACK_IMPORTED_MODULE_0__["default"] {
}


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/Request/Request.js":
/*!***************************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/Request/Request.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Errors */ "./node_modules/api-ai-javascript/es6/Errors.js");
/* harmony import */ var _XhrRequest__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../XhrRequest */ "./node_modules/api-ai-javascript/es6/XhrRequest.js");


class Request {
    constructor(apiAiClient, options) {
        this.apiAiClient = apiAiClient;
        this.options = options;
        this.uri = this.apiAiClient.getApiBaseUrl() + "query?v=" + this.apiAiClient.getApiVersion();
        this.requestMethod = _XhrRequest__WEBPACK_IMPORTED_MODULE_1__["default"].Method.POST;
        this.headers = {
            Authorization: "Bearer " + this.apiAiClient.getAccessToken(),
        };
        this.options.lang = this.apiAiClient.getApiLang();
        this.options.sessionId = this.apiAiClient.getSessionId();
    }
    static handleSuccess(xhr) {
        return Promise.resolve(JSON.parse(xhr.responseText));
    }
    static handleError(xhr) {
        let error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](null);
        try {
            const serverResponse = JSON.parse(xhr.responseText);
            if (serverResponse.status && serverResponse.status.errorDetails) {
                error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](serverResponse.status.errorDetails, serverResponse.status.code);
            }
            else {
                error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](xhr.statusText, xhr.status);
            }
        }
        catch (e) {
            error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](xhr.statusText, xhr.status);
        }
        return Promise.reject(error);
    }
    perform(overrideOptions = null) {
        const options = overrideOptions ? overrideOptions : this.options;
        return _XhrRequest__WEBPACK_IMPORTED_MODULE_1__["default"].ajax(this.requestMethod, this.uri, options, this.headers)
            .then(Request.handleSuccess.bind(this))
            .catch(Request.handleError.bind(this));
    }
}
/* harmony default export */ __webpack_exports__["default"] = (Request);


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/Request/TextRequest.js":
/*!*******************************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/Request/TextRequest.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TextRequest; });
/* harmony import */ var _Request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Request */ "./node_modules/api-ai-javascript/es6/Request/Request.js");

class TextRequest extends _Request__WEBPACK_IMPORTED_MODULE_0__["default"] {
}


/***/ }),

/***/ "./node_modules/api-ai-javascript/es6/XhrRequest.js":
/*!**********************************************************!*\
  !*** ./node_modules/api-ai-javascript/es6/XhrRequest.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * quick ts implementation of example from
 * https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Promise
 * with some minor improvements
 * @todo: test (?)
 * @todo: add node.js implementation with node's http inside. Just to make SDK cross-platform
 */
class XhrRequest {
    // Method that performs the ajax request
    static ajax(method, url, args = null, headers = null, options = {}) {
        // Creating a promise
        return new Promise((resolve, reject) => {
            // Instantiates the XMLHttpRequest
            const client = XhrRequest.createXMLHTTPObject();
            let uri = url;
            let payload = null;
            // Add given payload to get request
            if (args && (method === XhrRequest.Method.GET)) {
                uri += "?";
                let argcount = 0;
                for (const key in args) {
                    if (args.hasOwnProperty(key)) {
                        if (argcount++) {
                            uri += "&";
                        }
                        uri += encodeURIComponent(key) + "=" + encodeURIComponent(args[key]);
                    }
                }
            }
            else if (args) {
                if (!headers) {
                    headers = {};
                }
                headers["Content-Type"] = "application/json; charset=utf-8";
                payload = JSON.stringify(args);
            }
            for (const key in options) {
                if (key in client) {
                    client[key] = options[key];
                }
            }
            // hack: method[method] is somewhat like .toString for enum Method
            // should be made in normal way
            client.open(XhrRequest.Method[method], uri, true);
            // Add given headers
            if (headers) {
                for (const key in headers) {
                    if (headers.hasOwnProperty(key)) {
                        client.setRequestHeader(key, headers[key]);
                    }
                }
            }
            payload ? client.send(payload) : client.send();
            client.onload = () => {
                if (client.status >= 200 && client.status < 300) {
                    // Performs the function "resolve" when this.status is equal to 2xx
                    resolve(client);
                }
                else {
                    // Performs the function "reject" when this.status is different than 2xx
                    reject(client);
                }
            };
            client.onerror = () => {
                reject(client);
            };
        });
    }
    static get(url, payload = null, headers = null, options = {}) {
        return XhrRequest.ajax(XhrRequest.Method.GET, url, payload, headers, options);
    }
    static post(url, payload = null, headers = null, options = {}) {
        return XhrRequest.ajax(XhrRequest.Method.POST, url, payload, headers, options);
    }
    static put(url, payload = null, headers = null, options = {}) {
        return XhrRequest.ajax(XhrRequest.Method.PUT, url, payload, headers, options);
    }
    static delete(url, payload = null, headers = null, options = {}) {
        return XhrRequest.ajax(XhrRequest.Method.DELETE, url, payload, headers, options);
    }
    static createXMLHTTPObject() {
        let xmlhttp = null;
        for (const i of XhrRequest.XMLHttpFactories) {
            try {
                xmlhttp = i();
            }
            catch (e) {
                continue;
            }
            break;
        }
        return xmlhttp;
    }
}
XhrRequest.XMLHttpFactories = [
    () => new XMLHttpRequest(),
    () => new window["ActiveXObject"]("Msxml2.XMLHTTP"),
    () => new window["ActiveXObject"]("Msxml3.XMLHTTP"),
    () => new window["ActiveXObject"]("Microsoft.XMLHTTP")
];
(function (XhrRequest) {
    let Method;
    (function (Method) {
        Method[Method["GET"] = "GET"] = "GET";
        Method[Method["POST"] = "POST"] = "POST";
        Method[Method["PUT"] = "PUT"] = "PUT";
        Method[Method["DELETE"] = "DELETE"] = "DELETE";
    })(Method = XhrRequest.Method || (XhrRequest.Method = {}));
})(XhrRequest || (XhrRequest = {}));
/* harmony default export */ __webpack_exports__["default"] = (XhrRequest);


/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar [color]=\"isRecording ? 'info':'light'\">\n        <ion-buttons slot=\"start\">\n            <ion-menu-button color=\"primary\" menu=\"first\"></ion-menu-button>\n        </ion-buttons>\n\n        <ion-title class=\"titulo\">Asistente Inteligente Alzaid</ion-title>\n\n        <ion-buttons slot=\"end\" (click)=\"perfil()\">\n            <ion-avatar>\n                <img src=\"{{user.picture}}\">\n            </ion-avatar>\n        </ion-buttons>\n\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n    <ion-grid fixed>\n        <ion-row>\n            <ion-col>\n                <ion-item>\n                    <ion-label class=\"saludo\">¡Hola {{user.name}}!</ion-label>\n                </ion-item>\n            </ion-col>\n        </ion-row>\n\n    </ion-grid>\n    <ion-card class=\"chatbody\">\n        <ion-content #chatBody>\n            <ion-card-content>\n                <ng-container *ngFor=\"let message of messages\">\n                    <div *ngIf=\"message.content!='init_chat_saludo'\" class=\"message\" [ngClass]=\"{ 'from': message.sentBy === 'bot',\n                                            'to':   message.sentBy === 'user' }\">\n\n                        <!-- <img class=\"profile_pic\" src=\"{{message.profile_pic}}\"> -->\n                        <img *ngIf=\"message.sentBy === 'bot'\" class=\"profile_pic\" src=\"{{message.profile_pic}}\">\n                        <img *ngIf=\"message.sentBy === 'user'\" class=\"profile_pic\" src=\"{{user.picture}}\">\n                        <div *ngIf=\"message.placeholder\">\n                            <img class=\"placeholder\" src=\"../../assets/img/typing.gif\">\n                        </div>\n                        <span class=\"text\">{{ message.content }}</span>\n\n                    </div>\n                </ng-container>\n            </ion-card-content>\n        </ion-content>\n    </ion-card>\n</ion-content>\n\n<ion-footer>\n    <div>\n\n        <ion-row>\n            <ion-col size=\"8\">\n                <ion-input padding-start type=\"text\" placeholder=\"Escribe un mensaje\" [(ngModel)]=\"input\"></ion-input>\n            </ion-col>\n            <ion-col size=\"2\">\n                <ion-button color=\"primary\" ion-button size=\"default\" (click)=\"send()\">\n                    <ion-icon name=\"send\"></ion-icon>\n                </ion-button>\n            </ion-col>\n            <ion-col size=\"2\">\n                <ion-button color=\"success\" ion-button size=\"default\" (click)=\"startListening()\">\n                    <ion-icon name=\"mic\"></ion-icon>\n                </ion-button>\n            </ion-col>\n        </ion-row>\n    </div>\n</ion-footer>");

/***/ }),

/***/ "./src/app/models/message.model.ts":
/*!*****************************************!*\
  !*** ./src/app/models/message.model.ts ***!
  \*****************************************/
/*! exports provided: Message */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Message", function() { return Message; });
// Message class
class Message {
    constructor(content, sentBy, placeholder = false, action = null) {
        this.content = content;
        this.sentBy = sentBy;
        this.placeholder = placeholder;
        this.action = action;
        //You can define the message profile pic
        this.profile_pic = (sentBy == 'user') ? "../../assets/img/user.png" : "../../assets/img/bot.png";
    }
}


/***/ }),

/***/ "./src/app/pages/home/home-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/home/home-routing.module.ts ***!
  \***************************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HomePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home-routing.module */ "./src/app/pages/home/home-routing.module.ts");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".titulo {\n  font-size: 100%;\n  text-align: left;\n}\n\n.saludo {\n  font-size: 100%;\n  text-align: center;\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n.message {\n  border-radius: 60px;\n  margin: 0 15px 10px;\n  padding: 15px 20px;\n  position: relative;\n  padding-top: 25px;\n  padding-bottom: 25px;\n}\n\n.message .profile_pic {\n  height: 50px;\n  width: 50px;\n  display: inline;\n  position: absolute;\n  top: 10px;\n  border-radius: 50%;\n  border: 1px solid gray;\n}\n\n.message.to {\n  background-color: #2095FE;\n  color: #fff;\n  margin-left: 40px;\n  text-align: right;\n  padding-right: 65px;\n}\n\n.message.to .profile_pic {\n  right: 10px;\n}\n\n.message.from {\n  background-color: #E5E4E9;\n  color: #363636;\n  margin-right: 40px;\n  text-align: left;\n  padding-left: 65px;\n}\n\n.message.from .profile_pic {\n  left: 10px;\n}\n\n.message.to + .message.to,\n.message.from + .message.from {\n  margin-top: -10px;\n}\n\n.chatbody {\n  height: 85%;\n}\n\n#chatBody {\n  height: 100%;\n  overflow: scroll;\n}\n\nimg.placeholder {\n  width: 60px;\n}\n\ndiv.fixedContent {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUdBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFFQSxpQkFBQTtFQUNBLG9CQUFBO0FBREo7O0FBS0E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0FBRko7O0FBS0E7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFGSjs7QUFHSTtFQUNJLFdBQUE7QUFEUjs7QUFLQTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUZKOztBQUdJO0VBQ0ksVUFBQTtBQURSOztBQUtBOztFQUVJLGlCQUFBO0FBRko7O0FBS0E7RUFDSSxXQUFBO0FBRko7O0FBS0E7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7QUFGSjs7QUFLQTtFQUNJLFdBQUE7QUFGSjs7QUFLQTtFQUNJLGtCQUFBO0FBRkoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdHVsbyB7XHJcbiAgICBmb250LXNpemU6IDEwMCU7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG4uc2FsdWRvIHtcclxuICAgIGZvbnQtc2l6ZTogMTAwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuI2NvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxufVxyXG5cclxuI2NvbnRhaW5lciBzdHJvbmcge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XHJcbn1cclxuXHJcbi8vQ2hhdGJvdFxyXG4ubWVzc2FnZSB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2MHB4O1xyXG4gICAgbWFyZ2luOiAwIDE1cHggMTBweDtcclxuICAgIHBhZGRpbmc6IDE1cHggMjBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8vZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBwYWRkaW5nLXRvcDogMjVweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAyNXB4O1xyXG4gICAgO1xyXG59XHJcblxyXG4ubWVzc2FnZSAucHJvZmlsZV9waWMge1xyXG4gICAgaGVpZ2h0OiA1MHB4O1xyXG4gICAgd2lkdGg6IDUwcHg7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCBncmF5O1xyXG59XHJcblxyXG4ubWVzc2FnZS50byB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjA5NUZFO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBtYXJnaW4tbGVmdDogNDBweDtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgcGFkZGluZy1yaWdodDogNjVweDtcclxuICAgIC5wcm9maWxlX3BpYyB7XHJcbiAgICAgICAgcmlnaHQ6IDEwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5tZXNzYWdlLmZyb20ge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U1RTRFOTtcclxuICAgIGNvbG9yOiAjMzYzNjM2O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHBhZGRpbmctbGVmdDogNjVweDtcclxuICAgIC5wcm9maWxlX3BpYyB7XHJcbiAgICAgICAgbGVmdDogMTBweDtcclxuICAgIH1cclxufVxyXG5cclxuLm1lc3NhZ2UudG8rLm1lc3NhZ2UudG8sXHJcbi5tZXNzYWdlLmZyb20rLm1lc3NhZ2UuZnJvbSB7XHJcbiAgICBtYXJnaW4tdG9wOiAtMTBweDtcclxufVxyXG5cclxuLmNoYXRib2R5IHtcclxuICAgIGhlaWdodDogODUlO1xyXG59XHJcblxyXG4jY2hhdEJvZHkge1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcclxufVxyXG5cclxuaW1nLnBsYWNlaG9sZGVyIHtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG59XHJcblxyXG5kaXYuZml4ZWRDb250ZW50IHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _models_message_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../models/message.model */ "./src/app/models/message.model.ts");
/* harmony import */ var _services_chat_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/chat.service */ "./src/app/services/chat.service.ts");
/* harmony import */ var _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/text-to-speech/ngx */ "./node_modules/@ionic-native/text-to-speech/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/speech-recognition/ngx */ "./node_modules/@ionic-native/speech-recognition/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _models_user_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../models/user.model */ "./src/app/models/user.model.ts");










let HomePage = class HomePage {
    constructor(menu, router, navCtrl, plt, cd, chat, speechRecognition, tts, storage) {
        this.menu = menu;
        this.router = router;
        this.navCtrl = navCtrl;
        this.plt = plt;
        this.cd = cd;
        this.chat = chat;
        this.speechRecognition = speechRecognition;
        this.tts = tts;
        this.storage = storage;
        this.isRecording = false;
        this.permissionGranted = false;
        //DialogFlow
        this.messages = [];
        this.input = '';
        this.user = new _models_user_model__WEBPACK_IMPORTED_MODULE_9__["User"]();
        this.menu.enable(true, 'first');
        this.storage.get('usuario').then((val) => {
            this.user = val;
        });
        if (!this.user) {
            this.user = new _models_user_model__WEBPACK_IMPORTED_MODULE_9__["User"]();
        }
    }
    ngOnInit() {
        this.subscription = this.chat.conversation.subscribe((data) => this.responseonseHandler(data));
        this.sendMessage("init_chat_saludo");
        //this.startListening();
    }
    ngOnDestroy() {
        if (this.subscription)
            this.subscription.unsubscribe();
        this.messages = [];
        this.stopListening();
    }
    perfil() {
        this.router.navigateByUrl("/profile");
    }
    getPermission() {
        // Request permissions
        this.speechRecognition.requestPermission()
            .then(() => this.permissionGrantedNotify(), () => this.permissionDeniedNotify());
    }
    checkPermission() {
        // Check permission
        this.speechRecognition.hasPermission()
            .then((hasPermission) => this.permissionGranted = hasPermission);
    }
    permissionGrantedNotify() {
        this.permissionGranted = true;
        //this.startListening();
    }
    permissionDeniedNotify() {
        this.permissionGranted = false;
        alert("La App necesita permisos de micrófono para usar la voz.");
    }
    startListening() {
        if (!this.permissionGranted) {
            this.getPermission();
            return;
        }
        let options = {
            language: 'es-MX'
        };
        this.isRecording = true;
        // Start the recognition process
        this.speechRecognition.startListening(options)
            .subscribe(matches => {
            this.matches = matches;
            this.sendMessage(this.matches[0]);
            this.isRecording = false;
            this.cd.detectChanges();
        });
    }
    stopListening() {
        // Stop the recognition process (iOS only)
        this.speechRecognition.stopListening().then(() => {
            this.isRecording = false;
        });
    }
    isIos() {
        return this.plt.is('ios');
    }
    sendMessage(message) {
        this.chat.sendMessage(message);
        this.cd.detectChanges();
    }
    responseonseHandler(data) {
        console.log(data);
        if (data.length > 0) {
            this.scrollToBottom();
            if (data[0].sentBy == 'user') {
                //Add user question to messages list
                this.messages.push(data[0]);
                //Add fake messages with gif typing...
                this.messages.push(new _models_message_model__WEBPACK_IMPORTED_MODULE_4__["Message"]("", "bot", true));
            }
            if (data[0].sentBy == 'bot' && this.messages.length > 0) {
                //Replace placeholder (gif) with bot  responseonse
                this.messages[this.messages.length - 1] = data[0];
                //And now TTS
                this.tts.speak({
                    text: data[0].content,
                    locale: 'es-MX'
                })
                    .then(() => console.log('Success'))
                    .catch((reason) => console.log(reason));
                //execute action
                this.doAction(data[0]);
            }
        }
        this.cd.detectChanges();
    }
    send() {
        if (this.input != '') {
            this.sendMessage(this.input);
            this.input = '';
            setTimeout(() => {
                this.scrollToBottom();
            }, 10);
        }
    }
    scrollToBottom() {
        this.content.scrollToBottom(300); //300 for animate the scroll effect.
    }
    doAction(message) {
        if (message.action != "" && message.action != "input.unknown")
            setTimeout(() => {
                this.navCtrl.navigateRoot(["/home"]);
                // this.navCtrl.navigateRoot(["/"+message.action]);
            }, 2000);
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: _services_chat_service__WEBPACK_IMPORTED_MODULE_5__["ChatService"] },
    { type: _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_7__["SpeechRecognition"] },
    { type: _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_6__["TextToSpeech"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_8__["Storage"] }
];
HomePage.propDecorators = {
    content: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"], args: ['chatBody', { static: true },] }]
};
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")).default]
    })
], HomePage);



/***/ }),

/***/ "./src/app/services/chat.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/chat.service.ts ***!
  \******************************************/
/*! exports provided: ChatService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChatService", function() { return ChatService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var api_ai_javascript_es6_ApiAiClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! api-ai-javascript/es6/ApiAiClient */ "./node_modules/api-ai-javascript/es6/ApiAiClient.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _models_message_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/message.model */ "./src/app/models/message.model.ts");






let ChatService = class ChatService {
    constructor() {
        //Get API Key
        this.token = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].dialogflow.angularBot;
        this.client = new api_ai_javascript_es6_ApiAiClient__WEBPACK_IMPORTED_MODULE_3__["ApiAiClient"]({ accessToken: this.token });
        this.conversation = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]([]);
    }
    setResponseHandler(responseHandler) {
        this.responseHandler = responseHandler;
    }
    //Send and receive messages via DialogFlow
    sendMessage(msg) {
        const userMessage = new _models_message_model__WEBPACK_IMPORTED_MODULE_5__["Message"](msg, 'user');
        this.update(userMessage);
        return this.client.textRequest(msg)
            .then(res => {
            //get text of message
            const speech = res.result.fulfillment.speech;
            //Create new message
            const botMessage = new _models_message_model__WEBPACK_IMPORTED_MODULE_5__["Message"](speech, 'bot', false, res.result.action);
            this.update(botMessage);
        });
    }
    // Add message to source
    update(msg) {
        console.log(_models_message_model__WEBPACK_IMPORTED_MODULE_5__["Message"]);
        this.conversation.next([msg]);
    }
};
ChatService.ctorParameters = () => [];
ChatService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ChatService);



/***/ })

}]);
//# sourceMappingURL=pages-home-home-module-es2015.js.map