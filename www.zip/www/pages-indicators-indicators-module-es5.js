(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-indicators-indicators-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/indicators/indicators.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/indicators/indicators.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesIndicatorsIndicatorsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-header titulo=\"Indicadores\"></app-header>\n\n\n<ion-toolbar>\n    <ion-segment value=\"1\" (ionChange)=\"segmentChanged($event)\" color=\"primary\">\n        <ion-segment-button value=\"1\">\n            <ion-label>Paciente</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"2\">\n            <ion-label>Cuidador</ion-label>\n        </ion-segment-button>\n    </ion-segment>\n</ion-toolbar>\n\n\n<ion-content>\n    <ion-item *ngFor=\"let i of instruments_selected\">\n        <ion-label>\n            <h3>{{i.title}}</h3>\n            <p>{{i.current_value}}</p>\n        </ion-label>\n        <ion-button slot=\"end\" color=\"primary\" shape=\"round\" routerLink=\"instrument\">\n            <ion-icon name=\"list\"></ion-icon>\n        </ion-button>\n        <ion-button slot=\"end\" color=\"primary\" shape=\"round\">\n            <ion-icon name=\"pencil\"></ion-icon>\n        </ion-button>\n    </ion-item>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/indicators/indicators-routing.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/indicators/indicators-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: IndicatorsPageRoutingModule */

    /***/
    function srcAppPagesIndicatorsIndicatorsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "IndicatorsPageRoutingModule", function () {
        return IndicatorsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _indicators_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./indicators.page */
      "./src/app/pages/indicators/indicators.page.ts");

      var routes = [{
        path: '',
        component: _indicators_page__WEBPACK_IMPORTED_MODULE_3__["IndicatorsPage"]
      }, {
        path: 'instrument',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | instrument-instrument-module */
          [__webpack_require__.e("default~instrument-instrument-module~pages-login-login-module"), __webpack_require__.e("instrument-instrument-module")]).then(__webpack_require__.bind(null,
          /*! ./instrument/instrument.module */
          "./src/app/pages/indicators/instrument/instrument.module.ts")).then(function (m) {
            return m.InstrumentPageModule;
          });
        }
      }];

      var IndicatorsPageRoutingModule = function IndicatorsPageRoutingModule() {
        _classCallCheck(this, IndicatorsPageRoutingModule);
      };

      IndicatorsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], IndicatorsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/indicators/indicators.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/indicators/indicators.module.ts ***!
      \*******************************************************/

    /*! exports provided: IndicatorsPageModule */

    /***/
    function srcAppPagesIndicatorsIndicatorsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "IndicatorsPageModule", function () {
        return IndicatorsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _indicators_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./indicators-routing.module */
      "./src/app/pages/indicators/indicators-routing.module.ts");
      /* harmony import */


      var _indicators_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./indicators.page */
      "./src/app/pages/indicators/indicators.page.ts");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components/components.module */
      "./src/app/components/components.module.ts");

      var IndicatorsPageModule = function IndicatorsPageModule() {
        _classCallCheck(this, IndicatorsPageModule);
      };

      IndicatorsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _indicators_routing_module__WEBPACK_IMPORTED_MODULE_5__["IndicatorsPageRoutingModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
        declarations: [_indicators_page__WEBPACK_IMPORTED_MODULE_6__["IndicatorsPage"]]
      })], IndicatorsPageModule);
      /***/
    },

    /***/
    "./src/app/pages/indicators/indicators.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/pages/indicators/indicators.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesIndicatorsIndicatorsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZGljYXRvcnMvaW5kaWNhdG9ycy5wYWdlLnNjc3MifQ== */";
      /***/
    },

    /***/
    "./src/app/pages/indicators/indicators.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/indicators/indicators.page.ts ***!
      \*****************************************************/

    /*! exports provided: IndicatorsPage */

    /***/
    function srcAppPagesIndicatorsIndicatorsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "IndicatorsPage", function () {
        return IndicatorsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var IndicatorsPage = /*#__PURE__*/function () {
        function IndicatorsPage(router) {
          _classCallCheck(this, IndicatorsPage);

          this.router = router;
          this.instruments = [// 1 - Pacientes
          // 2 - Cuidadores
          {
            instrument: 'barthel',
            title: 'Actividades Básicas de la vida diaria',
            current_value: 'Dependencia leve',
            toWhom: 1
          }, {
            title: 'Actividades Instrumentales de la vida diaria',
            current_value: 'Dependencia moderada',
            toWhom: 1
          }, {
            title: 'Equilibrio y marcha',
            current_value: 'Alto riesgo de caída',
            toWhom: 1
          }, {
            title: 'Deterioro cognitivo',
            current_value: 'Deterioro leve',
            toWhom: 1
          }, {
            title: 'Escala Zarit',
            current_value: 'Sobrecarga leve',
            toWhom: 2
          }, {
            title: 'Escala HAD-A',
            current_value: 'Ansiedad moderada',
            toWhom: 2
          }, {
            title: 'Escala CES-D',
            current_value: 'Depresión moderada',
            toWhom: 2
          }];
          this.instruments_selected = [];
        }

        _createClass(IndicatorsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.cambiarSegment(1);
          }
        }, {
          key: "segmentChanged",
          value: function segmentChanged(event) {
            var valorSegmento = event.detail.value;
            this.cambiarSegment(valorSegmento);
          }
        }, {
          key: "cambiarSegment",
          value: function cambiarSegment(valorSegmento) {
            this.instruments_selected.length = 0;

            if (Number(valorSegmento) === 1) {
              var _iterator = _createForOfIteratorHelper(this.instruments),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var i = _step.value;

                  if (i.toWhom === 1) {
                    this.instruments_selected.push(i);
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            } else {
              var _iterator2 = _createForOfIteratorHelper(this.instruments),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var _i = _step2.value;

                  if (_i.toWhom === 2) {
                    this.instruments_selected.push(_i);
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }
          }
        }]);

        return IndicatorsPage;
      }();

      IndicatorsPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }];
      };

      IndicatorsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-indicators',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./indicators.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/indicators/indicators.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./indicators.page.scss */
        "./src/app/pages/indicators/indicators.page.scss"))["default"]]
      })], IndicatorsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-indicators-indicators-module-es5.js.map