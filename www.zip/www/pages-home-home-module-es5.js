(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _wrapNativeSuper(Class) { var _cache = typeof Map === "function" ? new Map() : undefined; _wrapNativeSuper = function _wrapNativeSuper(Class) { if (Class === null || !_isNativeFunction(Class)) return Class; if (typeof Class !== "function") { throw new TypeError("Super expression must either be null or a function"); } if (typeof _cache !== "undefined") { if (_cache.has(Class)) return _cache.get(Class); _cache.set(Class, Wrapper); } function Wrapper() { return _construct(Class, arguments, _getPrototypeOf(this).constructor); } Wrapper.prototype = Object.create(Class.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } }); return _setPrototypeOf(Wrapper, Class); }; return _wrapNativeSuper(Class); }

  function _construct(Parent, args, Class) { if (_isNativeReflectConstruct()) { _construct = Reflect.construct; } else { _construct = function _construct(Parent, args, Class) { var a = [null]; a.push.apply(a, args); var Constructor = Function.bind.apply(Parent, a); var instance = new Constructor(); if (Class) _setPrototypeOf(instance, Class.prototype); return instance; }; } return _construct.apply(null, arguments); }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

  function _isNativeFunction(fn) { return Function.toString.call(fn).indexOf("[native code]") !== -1; }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"], {
    /***/
    "./node_modules/api-ai-javascript/es6/ApiAiClient.js":
    /*!***********************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/ApiAiClient.js ***!
      \***********************************************************/

    /*! exports provided: IStreamClient, ApiAiConstants, ApiAiClient */

    /***/
    function node_modulesApiAiJavascriptEs6ApiAiClientJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiAiClient", function () {
        return ApiAiClient;
      });
      /* harmony import */


      var _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./ApiAiConstants */
      "./node_modules/api-ai-javascript/es6/ApiAiConstants.js");
      /* harmony import */


      var _Errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./Errors */
      "./node_modules/api-ai-javascript/es6/Errors.js");
      /* harmony import */


      var _Request_EventRequest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./Request/EventRequest */
      "./node_modules/api-ai-javascript/es6/Request/EventRequest.js");
      /* harmony import */


      var _Request_TextRequest__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./Request/TextRequest */
      "./node_modules/api-ai-javascript/es6/Request/TextRequest.js");
      /* harmony import */


      var _Interfaces__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./Interfaces */
      "./node_modules/api-ai-javascript/es6/Interfaces.js");
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "IStreamClient", function () {
        return _Interfaces__WEBPACK_IMPORTED_MODULE_4__["IStreamClient"];
      });
      /* harmony reexport (safe) */


      __webpack_require__.d(__webpack_exports__, "ApiAiConstants", function () {
        return _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"];
      });

      var ApiAiClient = /*#__PURE__*/function () {
        function ApiAiClient(options) {
          _classCallCheck(this, ApiAiClient);

          if (!options || !options.accessToken) {
            throw new _Errors__WEBPACK_IMPORTED_MODULE_1__["ApiAiClientConfigurationError"]("Access token is required for new ApiAi.Client instance");
          }

          this.accessToken = options.accessToken;
          this.apiLang = options.lang || _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_CLIENT_LANG;
          this.apiVersion = options.version || _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_API_VERSION;
          this.apiBaseUrl = options.baseUrl || _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_BASE_URL;
          this.sessionId = options.sessionId || this.guid();
        }

        _createClass(ApiAiClient, [{
          key: "textRequest",
          value: function textRequest(query) {
            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

            if (!query) {
              throw new _Errors__WEBPACK_IMPORTED_MODULE_1__["ApiAiClientConfigurationError"]("Query should not be empty");
            }

            options.query = query;
            return new _Request_TextRequest__WEBPACK_IMPORTED_MODULE_3__["default"](this, options).perform();
          }
        }, {
          key: "eventRequest",
          value: function eventRequest(eventName) {
            var eventData = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

            if (!eventName) {
              throw new _Errors__WEBPACK_IMPORTED_MODULE_1__["ApiAiClientConfigurationError"]("Event name can not be empty");
            }

            options.event = {
              name: eventName,
              data: eventData
            };
            return new _Request_EventRequest__WEBPACK_IMPORTED_MODULE_2__["EventRequest"](this, options).perform();
          } // @todo: implement local tts request

          /*public ttsRequest(query) {
              if (!query) {
                  throw new ApiAiClientConfigurationError("Query should not be empty");
              }
              return new TTSRequest(this).makeTTSRequest(query);
          }*/

          /*public userEntitiesRequest(options: IRequestOptions = {}): UserEntitiesRequest {
              return new UserEntitiesRequest(this, options);
          }*/

        }, {
          key: "getAccessToken",
          value: function getAccessToken() {
            return this.accessToken;
          }
        }, {
          key: "getApiVersion",
          value: function getApiVersion() {
            return this.apiVersion ? this.apiVersion : _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_API_VERSION;
          }
        }, {
          key: "getApiLang",
          value: function getApiLang() {
            return this.apiLang ? this.apiLang : _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_CLIENT_LANG;
          }
        }, {
          key: "getApiBaseUrl",
          value: function getApiBaseUrl() {
            return this.apiBaseUrl ? this.apiBaseUrl : _ApiAiConstants__WEBPACK_IMPORTED_MODULE_0__["ApiAiConstants"].DEFAULT_BASE_URL;
          }
        }, {
          key: "setSessionId",
          value: function setSessionId(sessionId) {
            this.sessionId = sessionId;
          }
        }, {
          key: "getSessionId",
          value: function getSessionId() {
            return this.sessionId;
          }
          /**
           * generates new random UUID
           * @returns {string}
           */

        }, {
          key: "guid",
          value: function guid() {
            var s4 = function s4() {
              return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
            };

            return s4() + s4() + "-" + s4() + "-" + s4() + "-" + s4() + "-" + s4() + s4() + s4();
          }
        }]);

        return ApiAiClient;
      }();
      /***/

    },

    /***/
    "./node_modules/api-ai-javascript/es6/ApiAiConstants.js":
    /*!**************************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/ApiAiConstants.js ***!
      \**************************************************************/

    /*! exports provided: ApiAiConstants */

    /***/
    function node_modulesApiAiJavascriptEs6ApiAiConstantsJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiAiConstants", function () {
        return ApiAiConstants;
      });

      var ApiAiConstants;

      (function (ApiAiConstants) {
        var AVAILABLE_LANGUAGES;

        (function (AVAILABLE_LANGUAGES) {
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["EN"] = "en"] = "EN";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["DE"] = "de"] = "DE";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ES"] = "es"] = "ES";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["PT_BR"] = "pt-BR"] = "PT_BR";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_HK"] = "zh-HK"] = "ZH_HK";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_CN"] = "zh-CN"] = "ZH_CN";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_TW"] = "zh-TW"] = "ZH_TW";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["NL"] = "nl"] = "NL";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["FR"] = "fr"] = "FR";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["IT"] = "it"] = "IT";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["JA"] = "ja"] = "JA";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["KO"] = "ko"] = "KO";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["PT"] = "pt"] = "PT";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["RU"] = "ru"] = "RU";
          AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["UK"] = "uk"] = "UK";
        })(AVAILABLE_LANGUAGES = ApiAiConstants.AVAILABLE_LANGUAGES || (ApiAiConstants.AVAILABLE_LANGUAGES = {}));

        ApiAiConstants.VERSION = "2.0.0-beta.20";
        ApiAiConstants.DEFAULT_BASE_URL = "https://api.api.ai/v1/";
        ApiAiConstants.DEFAULT_API_VERSION = "20150910";
        ApiAiConstants.DEFAULT_CLIENT_LANG = AVAILABLE_LANGUAGES.EN;
      })(ApiAiConstants || (ApiAiConstants = {}));
      /***/

    },

    /***/
    "./node_modules/api-ai-javascript/es6/Errors.js":
    /*!******************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/Errors.js ***!
      \******************************************************/

    /*! exports provided: ApiAiBaseError, ApiAiClientConfigurationError, ApiAiRequestError */

    /***/
    function node_modulesApiAiJavascriptEs6ErrorsJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiAiBaseError", function () {
        return ApiAiBaseError;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiAiClientConfigurationError", function () {
        return ApiAiClientConfigurationError;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiAiRequestError", function () {
        return ApiAiRequestError;
      });

      var ApiAiBaseError = /*#__PURE__*/function (_Error) {
        _inherits(ApiAiBaseError, _Error);

        var _super = _createSuper(ApiAiBaseError);

        function ApiAiBaseError(message) {
          var _this;

          _classCallCheck(this, ApiAiBaseError);

          _this = _super.call(this, message);
          _this.message = message;
          _this.stack = new Error().stack;
          return _this;
        }

        return ApiAiBaseError;
      }( /*#__PURE__*/_wrapNativeSuper(Error));

      var ApiAiClientConfigurationError = /*#__PURE__*/function (_ApiAiBaseError) {
        _inherits(ApiAiClientConfigurationError, _ApiAiBaseError);

        var _super2 = _createSuper(ApiAiClientConfigurationError);

        function ApiAiClientConfigurationError(message) {
          var _this2;

          _classCallCheck(this, ApiAiClientConfigurationError);

          _this2 = _super2.call(this, message);
          _this2.name = "ApiAiClientConfigurationError";
          return _this2;
        }

        return ApiAiClientConfigurationError;
      }(ApiAiBaseError);

      var ApiAiRequestError = /*#__PURE__*/function (_ApiAiBaseError2) {
        _inherits(ApiAiRequestError, _ApiAiBaseError2);

        var _super3 = _createSuper(ApiAiRequestError);

        function ApiAiRequestError(message) {
          var _this3;

          var code = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

          _classCallCheck(this, ApiAiRequestError);

          _this3 = _super3.call(this, message);
          _this3.message = message;
          _this3.code = code;
          _this3.name = "ApiAiRequestError";
          return _this3;
        }

        return ApiAiRequestError;
      }(ApiAiBaseError);
      /***/

    },

    /***/
    "./node_modules/api-ai-javascript/es6/Interfaces.js":
    /*!**********************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/Interfaces.js ***!
      \**********************************************************/

    /*! exports provided: IStreamClient */

    /***/
    function node_modulesApiAiJavascriptEs6InterfacesJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "IStreamClient", function () {
        return IStreamClient;
      });

      var IStreamClient;

      (function (IStreamClient) {
        var ERROR;

        (function (ERROR) {
          ERROR[ERROR["ERR_NETWORK"] = 0] = "ERR_NETWORK";
          ERROR[ERROR["ERR_AUDIO"] = 1] = "ERR_AUDIO";
          ERROR[ERROR["ERR_SERVER"] = 2] = "ERR_SERVER";
          ERROR[ERROR["ERR_CLIENT"] = 3] = "ERR_CLIENT";
        })(ERROR = IStreamClient.ERROR || (IStreamClient.ERROR = {}));

        var EVENT;

        (function (EVENT) {
          EVENT[EVENT["MSG_WAITING_MICROPHONE"] = 0] = "MSG_WAITING_MICROPHONE";
          EVENT[EVENT["MSG_MEDIA_STREAM_CREATED"] = 1] = "MSG_MEDIA_STREAM_CREATED";
          EVENT[EVENT["MSG_INIT_RECORDER"] = 2] = "MSG_INIT_RECORDER";
          EVENT[EVENT["MSG_RECORDING"] = 3] = "MSG_RECORDING";
          EVENT[EVENT["MSG_SEND"] = 4] = "MSG_SEND";
          EVENT[EVENT["MSG_SEND_EMPTY"] = 5] = "MSG_SEND_EMPTY";
          EVENT[EVENT["MSG_SEND_EOS_OR_JSON"] = 6] = "MSG_SEND_EOS_OR_JSON";
          EVENT[EVENT["MSG_WEB_SOCKET"] = 7] = "MSG_WEB_SOCKET";
          EVENT[EVENT["MSG_WEB_SOCKET_OPEN"] = 8] = "MSG_WEB_SOCKET_OPEN";
          EVENT[EVENT["MSG_WEB_SOCKET_CLOSE"] = 9] = "MSG_WEB_SOCKET_CLOSE";
          EVENT[EVENT["MSG_STOP"] = 10] = "MSG_STOP";
          EVENT[EVENT["MSG_CONFIG_CHANGED"] = 11] = "MSG_CONFIG_CHANGED";
        })(EVENT = IStreamClient.EVENT || (IStreamClient.EVENT = {}));
      })(IStreamClient || (IStreamClient = {}));
      /***/

    },

    /***/
    "./node_modules/api-ai-javascript/es6/Request/EventRequest.js":
    /*!********************************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/Request/EventRequest.js ***!
      \********************************************************************/

    /*! exports provided: EventRequest */

    /***/
    function node_modulesApiAiJavascriptEs6RequestEventRequestJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EventRequest", function () {
        return EventRequest;
      });
      /* harmony import */


      var _Request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./Request */
      "./node_modules/api-ai-javascript/es6/Request/Request.js");

      var EventRequest = /*#__PURE__*/function (_Request__WEBPACK_IMP) {
        _inherits(EventRequest, _Request__WEBPACK_IMP);

        var _super4 = _createSuper(EventRequest);

        function EventRequest() {
          _classCallCheck(this, EventRequest);

          return _super4.apply(this, arguments);
        }

        return EventRequest;
      }(_Request__WEBPACK_IMPORTED_MODULE_0__["default"]);
      /***/

    },

    /***/
    "./node_modules/api-ai-javascript/es6/Request/Request.js":
    /*!***************************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/Request/Request.js ***!
      \***************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesApiAiJavascriptEs6RequestRequestJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _Errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ../Errors */
      "./node_modules/api-ai-javascript/es6/Errors.js");
      /* harmony import */


      var _XhrRequest__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ../XhrRequest */
      "./node_modules/api-ai-javascript/es6/XhrRequest.js");

      var Request = /*#__PURE__*/function () {
        function Request(apiAiClient, options) {
          _classCallCheck(this, Request);

          this.apiAiClient = apiAiClient;
          this.options = options;
          this.uri = this.apiAiClient.getApiBaseUrl() + "query?v=" + this.apiAiClient.getApiVersion();
          this.requestMethod = _XhrRequest__WEBPACK_IMPORTED_MODULE_1__["default"].Method.POST;
          this.headers = {
            Authorization: "Bearer " + this.apiAiClient.getAccessToken()
          };
          this.options.lang = this.apiAiClient.getApiLang();
          this.options.sessionId = this.apiAiClient.getSessionId();
        }

        _createClass(Request, [{
          key: "perform",
          value: function perform() {
            var overrideOptions = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
            var options = overrideOptions ? overrideOptions : this.options;
            return _XhrRequest__WEBPACK_IMPORTED_MODULE_1__["default"].ajax(this.requestMethod, this.uri, options, this.headers).then(Request.handleSuccess.bind(this))["catch"](Request.handleError.bind(this));
          }
        }], [{
          key: "handleSuccess",
          value: function handleSuccess(xhr) {
            return Promise.resolve(JSON.parse(xhr.responseText));
          }
        }, {
          key: "handleError",
          value: function handleError(xhr) {
            var error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](null);

            try {
              var serverResponse = JSON.parse(xhr.responseText);

              if (serverResponse.status && serverResponse.status.errorDetails) {
                error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](serverResponse.status.errorDetails, serverResponse.status.code);
              } else {
                error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](xhr.statusText, xhr.status);
              }
            } catch (e) {
              error = new _Errors__WEBPACK_IMPORTED_MODULE_0__["ApiAiRequestError"](xhr.statusText, xhr.status);
            }

            return Promise.reject(error);
          }
        }]);

        return Request;
      }();
      /* harmony default export */


      __webpack_exports__["default"] = Request;
      /***/
    },

    /***/
    "./node_modules/api-ai-javascript/es6/Request/TextRequest.js":
    /*!*******************************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/Request/TextRequest.js ***!
      \*******************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesApiAiJavascriptEs6RequestTextRequestJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "default", function () {
        return TextRequest;
      });
      /* harmony import */


      var _Request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./Request */
      "./node_modules/api-ai-javascript/es6/Request/Request.js");

      var TextRequest = /*#__PURE__*/function (_Request__WEBPACK_IMP2) {
        _inherits(TextRequest, _Request__WEBPACK_IMP2);

        var _super5 = _createSuper(TextRequest);

        function TextRequest() {
          _classCallCheck(this, TextRequest);

          return _super5.apply(this, arguments);
        }

        return TextRequest;
      }(_Request__WEBPACK_IMPORTED_MODULE_0__["default"]);
      /***/

    },

    /***/
    "./node_modules/api-ai-javascript/es6/XhrRequest.js":
    /*!**********************************************************!*\
      !*** ./node_modules/api-ai-javascript/es6/XhrRequest.js ***!
      \**********************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesApiAiJavascriptEs6XhrRequestJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /**
       * quick ts implementation of example from
       * https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Promise
       * with some minor improvements
       * @todo: test (?)
       * @todo: add node.js implementation with node's http inside. Just to make SDK cross-platform
       */


      var XhrRequest = /*#__PURE__*/function () {
        function XhrRequest() {
          _classCallCheck(this, XhrRequest);
        }

        _createClass(XhrRequest, null, [{
          key: "ajax",
          // Method that performs the ajax request
          value: function ajax(method, url) {
            var args = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            var headers = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
            var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
            // Creating a promise
            return new Promise(function (resolve, reject) {
              // Instantiates the XMLHttpRequest
              var client = XhrRequest.createXMLHTTPObject();
              var uri = url;
              var payload = null; // Add given payload to get request

              if (args && method === XhrRequest.Method.GET) {
                uri += "?";
                var argcount = 0;

                for (var key in args) {
                  if (args.hasOwnProperty(key)) {
                    if (argcount++) {
                      uri += "&";
                    }

                    uri += encodeURIComponent(key) + "=" + encodeURIComponent(args[key]);
                  }
                }
              } else if (args) {
                if (!headers) {
                  headers = {};
                }

                headers["Content-Type"] = "application/json; charset=utf-8";
                payload = JSON.stringify(args);
              }

              for (var _key in options) {
                if (_key in client) {
                  client[_key] = options[_key];
                }
              } // hack: method[method] is somewhat like .toString for enum Method
              // should be made in normal way


              client.open(XhrRequest.Method[method], uri, true); // Add given headers

              if (headers) {
                for (var _key2 in headers) {
                  if (headers.hasOwnProperty(_key2)) {
                    client.setRequestHeader(_key2, headers[_key2]);
                  }
                }
              }

              payload ? client.send(payload) : client.send();

              client.onload = function () {
                if (client.status >= 200 && client.status < 300) {
                  // Performs the function "resolve" when this.status is equal to 2xx
                  resolve(client);
                } else {
                  // Performs the function "reject" when this.status is different than 2xx
                  reject(client);
                }
              };

              client.onerror = function () {
                reject(client);
              };
            });
          }
        }, {
          key: "get",
          value: function get(url) {
            var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
            var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
            return XhrRequest.ajax(XhrRequest.Method.GET, url, payload, headers, options);
          }
        }, {
          key: "post",
          value: function post(url) {
            var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
            var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
            return XhrRequest.ajax(XhrRequest.Method.POST, url, payload, headers, options);
          }
        }, {
          key: "put",
          value: function put(url) {
            var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
            var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
            return XhrRequest.ajax(XhrRequest.Method.PUT, url, payload, headers, options);
          }
        }, {
          key: "delete",
          value: function _delete(url) {
            var payload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
            var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
            var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
            return XhrRequest.ajax(XhrRequest.Method.DELETE, url, payload, headers, options);
          }
        }, {
          key: "createXMLHTTPObject",
          value: function createXMLHTTPObject() {
            var xmlhttp = null;

            var _iterator = _createForOfIteratorHelper(XhrRequest.XMLHttpFactories),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var i = _step.value;

                try {
                  xmlhttp = i();
                } catch (e) {
                  continue;
                }

                break;
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            return xmlhttp;
          }
        }]);

        return XhrRequest;
      }();

      XhrRequest.XMLHttpFactories = [function () {
        return new XMLHttpRequest();
      }, function () {
        return new window["ActiveXObject"]("Msxml2.XMLHTTP");
      }, function () {
        return new window["ActiveXObject"]("Msxml3.XMLHTTP");
      }, function () {
        return new window["ActiveXObject"]("Microsoft.XMLHTTP");
      }];

      (function (XhrRequest) {
        var Method;

        (function (Method) {
          Method[Method["GET"] = "GET"] = "GET";
          Method[Method["POST"] = "POST"] = "POST";
          Method[Method["PUT"] = "PUT"] = "PUT";
          Method[Method["DELETE"] = "DELETE"] = "DELETE";
        })(Method = XhrRequest.Method || (XhrRequest.Method = {}));
      })(XhrRequest || (XhrRequest = {}));
      /* harmony default export */


      __webpack_exports__["default"] = XhrRequest;
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [color]=\"isRecording ? 'info':'light'\">\n        <ion-buttons slot=\"start\">\n            <ion-menu-button color=\"primary\" menu=\"first\"></ion-menu-button>\n        </ion-buttons>\n\n        <ion-title class=\"titulo\">Asistente Inteligente Alzaid</ion-title>\n\n        <ion-buttons slot=\"end\" (click)=\"perfil()\">\n            <ion-avatar>\n                <img src=\"{{user.picture}}\">\n            </ion-avatar>\n        </ion-buttons>\n\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n    <ion-grid fixed>\n        <ion-row>\n            <ion-col>\n                <ion-item>\n                    <ion-label class=\"saludo\">¡Hola {{user.name}}!</ion-label>\n                </ion-item>\n            </ion-col>\n        </ion-row>\n\n    </ion-grid>\n    <ion-card class=\"chatbody\">\n        <ion-content #chatBody>\n            <ion-card-content>\n                <ng-container *ngFor=\"let message of messages\">\n                    <div *ngIf=\"message.content!='init_chat_saludo'\" class=\"message\" [ngClass]=\"{ 'from': message.sentBy === 'bot',\n                                            'to':   message.sentBy === 'user' }\">\n\n                        <!-- <img class=\"profile_pic\" src=\"{{message.profile_pic}}\"> -->\n                        <img *ngIf=\"message.sentBy === 'bot'\" class=\"profile_pic\" src=\"{{message.profile_pic}}\">\n                        <img *ngIf=\"message.sentBy === 'user'\" class=\"profile_pic\" src=\"{{user.picture}}\">\n                        <div *ngIf=\"message.placeholder\">\n                            <img class=\"placeholder\" src=\"../../assets/img/typing.gif\">\n                        </div>\n                        <span class=\"text\">{{ message.content }}</span>\n\n                    </div>\n                </ng-container>\n            </ion-card-content>\n        </ion-content>\n    </ion-card>\n</ion-content>\n\n<ion-footer>\n    <div>\n\n        <ion-row>\n            <ion-col size=\"8\">\n                <ion-input padding-start type=\"text\" placeholder=\"Escribe un mensaje\" [(ngModel)]=\"input\"></ion-input>\n            </ion-col>\n            <ion-col size=\"2\">\n                <ion-button color=\"primary\" ion-button size=\"default\" (click)=\"send()\">\n                    <ion-icon name=\"send\"></ion-icon>\n                </ion-button>\n            </ion-col>\n            <ion-col size=\"2\">\n                <ion-button color=\"success\" ion-button size=\"default\" (click)=\"startListening()\">\n                    <ion-icon name=\"mic\"></ion-icon>\n                </ion-button>\n            </ion-col>\n        </ion-row>\n    </div>\n</ion-footer>";
      /***/
    },

    /***/
    "./src/app/models/message.model.ts":
    /*!*****************************************!*\
      !*** ./src/app/models/message.model.ts ***!
      \*****************************************/

    /*! exports provided: Message */

    /***/
    function srcAppModelsMessageModelTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Message", function () {
        return Message;
      }); // Message class


      var Message = function Message(content, sentBy) {
        var placeholder = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
        var action = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;

        _classCallCheck(this, Message);

        this.content = content;
        this.sentBy = sentBy;
        this.placeholder = placeholder;
        this.action = action; //You can define the message profile pic

        this.profile_pic = sentBy == 'user' ? "../../assets/img/user.png" : "../../assets/img/bot.png";
      };
      /***/

    },

    /***/
    "./src/app/pages/home/home-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/home/home-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppPagesHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/pages/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/home/home.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/pages/home/home.module.ts ***!
      \*******************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppPagesHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/pages/home/home-routing.module.ts");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/pages/home/home.page.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/pages/home/home.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/pages/home/home.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".titulo {\n  font-size: 100%;\n  text-align: left;\n}\n\n.saludo {\n  font-size: 100%;\n  text-align: center;\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n.message {\n  border-radius: 60px;\n  margin: 0 15px 10px;\n  padding: 15px 20px;\n  position: relative;\n  padding-top: 25px;\n  padding-bottom: 25px;\n}\n\n.message .profile_pic {\n  height: 50px;\n  width: 50px;\n  display: inline;\n  position: absolute;\n  top: 10px;\n  border-radius: 50%;\n  border: 1px solid gray;\n}\n\n.message.to {\n  background-color: #2095FE;\n  color: #fff;\n  margin-left: 40px;\n  text-align: right;\n  padding-right: 65px;\n}\n\n.message.to .profile_pic {\n  right: 10px;\n}\n\n.message.from {\n  background-color: #E5E4E9;\n  color: #363636;\n  margin-right: 40px;\n  text-align: left;\n  padding-left: 65px;\n}\n\n.message.from .profile_pic {\n  left: 10px;\n}\n\n.message.to + .message.to,\n.message.from + .message.from {\n  margin-top: -10px;\n}\n\n.chatbody {\n  height: 85%;\n}\n\n#chatBody {\n  height: 100%;\n  overflow: scroll;\n}\n\nimg.placeholder {\n  width: 60px;\n}\n\ndiv.fixedContent {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUdBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFFQSxpQkFBQTtFQUNBLG9CQUFBO0FBREo7O0FBS0E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0FBRko7O0FBS0E7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFGSjs7QUFHSTtFQUNJLFdBQUE7QUFEUjs7QUFLQTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUZKOztBQUdJO0VBQ0ksVUFBQTtBQURSOztBQUtBOztFQUVJLGlCQUFBO0FBRko7O0FBS0E7RUFDSSxXQUFBO0FBRko7O0FBS0E7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7QUFGSjs7QUFLQTtFQUNJLFdBQUE7QUFGSjs7QUFLQTtFQUNJLGtCQUFBO0FBRkoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdHVsbyB7XHJcbiAgICBmb250LXNpemU6IDEwMCU7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG4uc2FsdWRvIHtcclxuICAgIGZvbnQtc2l6ZTogMTAwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuI2NvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxufVxyXG5cclxuI2NvbnRhaW5lciBzdHJvbmcge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI2cHg7XHJcbn1cclxuXHJcbi8vQ2hhdGJvdFxyXG4ubWVzc2FnZSB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2MHB4O1xyXG4gICAgbWFyZ2luOiAwIDE1cHggMTBweDtcclxuICAgIHBhZGRpbmc6IDE1cHggMjBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8vZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBwYWRkaW5nLXRvcDogMjVweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAyNXB4O1xyXG4gICAgO1xyXG59XHJcblxyXG4ubWVzc2FnZSAucHJvZmlsZV9waWMge1xyXG4gICAgaGVpZ2h0OiA1MHB4O1xyXG4gICAgd2lkdGg6IDUwcHg7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCBncmF5O1xyXG59XHJcblxyXG4ubWVzc2FnZS50byB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjA5NUZFO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBtYXJnaW4tbGVmdDogNDBweDtcclxuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgcGFkZGluZy1yaWdodDogNjVweDtcclxuICAgIC5wcm9maWxlX3BpYyB7XHJcbiAgICAgICAgcmlnaHQ6IDEwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5tZXNzYWdlLmZyb20ge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0U1RTRFOTtcclxuICAgIGNvbG9yOiAjMzYzNjM2O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHBhZGRpbmctbGVmdDogNjVweDtcclxuICAgIC5wcm9maWxlX3BpYyB7XHJcbiAgICAgICAgbGVmdDogMTBweDtcclxuICAgIH1cclxufVxyXG5cclxuLm1lc3NhZ2UudG8rLm1lc3NhZ2UudG8sXHJcbi5tZXNzYWdlLmZyb20rLm1lc3NhZ2UuZnJvbSB7XHJcbiAgICBtYXJnaW4tdG9wOiAtMTBweDtcclxufVxyXG5cclxuLmNoYXRib2R5IHtcclxuICAgIGhlaWdodDogODUlO1xyXG59XHJcblxyXG4jY2hhdEJvZHkge1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcclxufVxyXG5cclxuaW1nLnBsYWNlaG9sZGVyIHtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG59XHJcblxyXG5kaXYuZml4ZWRDb250ZW50IHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/home/home.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/pages/home/home.page.ts ***!
      \*****************************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppPagesHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _models_message_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../models/message.model */
      "./src/app/models/message.model.ts");
      /* harmony import */


      var _services_chat_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../services/chat.service */
      "./src/app/services/chat.service.ts");
      /* harmony import */


      var _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/text-to-speech/ngx */
      "./node_modules/@ionic-native/text-to-speech/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic-native/speech-recognition/ngx */
      "./node_modules/@ionic-native/speech-recognition/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _models_user_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../models/user.model */
      "./src/app/models/user.model.ts");

      var HomePage = /*#__PURE__*/function () {
        function HomePage(menu, router, navCtrl, plt, cd, chat, speechRecognition, tts, storage) {
          var _this4 = this;

          _classCallCheck(this, HomePage);

          this.menu = menu;
          this.router = router;
          this.navCtrl = navCtrl;
          this.plt = plt;
          this.cd = cd;
          this.chat = chat;
          this.speechRecognition = speechRecognition;
          this.tts = tts;
          this.storage = storage;
          this.isRecording = false;
          this.permissionGranted = false; //DialogFlow

          this.messages = [];
          this.input = '';
          this.user = new _models_user_model__WEBPACK_IMPORTED_MODULE_9__["User"]();
          this.menu.enable(true, 'first');
          this.storage.get('usuario').then(function (val) {
            _this4.user = val;
          });

          if (!this.user) {
            this.user = new _models_user_model__WEBPACK_IMPORTED_MODULE_9__["User"]();
          }
        }

        _createClass(HomePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this5 = this;

            this.subscription = this.chat.conversation.subscribe(function (data) {
              return _this5.responseonseHandler(data);
            });
            this.sendMessage("init_chat_saludo"); //this.startListening();
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            if (this.subscription) this.subscription.unsubscribe();
            this.messages = [];
            this.stopListening();
          }
        }, {
          key: "perfil",
          value: function perfil() {
            this.router.navigateByUrl("/profile");
          }
        }, {
          key: "getPermission",
          value: function getPermission() {
            var _this6 = this;

            // Request permissions
            this.speechRecognition.requestPermission().then(function () {
              return _this6.permissionGrantedNotify();
            }, function () {
              return _this6.permissionDeniedNotify();
            });
          }
        }, {
          key: "checkPermission",
          value: function checkPermission() {
            var _this7 = this;

            // Check permission
            this.speechRecognition.hasPermission().then(function (hasPermission) {
              return _this7.permissionGranted = hasPermission;
            });
          }
        }, {
          key: "permissionGrantedNotify",
          value: function permissionGrantedNotify() {
            this.permissionGranted = true; //this.startListening();
          }
        }, {
          key: "permissionDeniedNotify",
          value: function permissionDeniedNotify() {
            this.permissionGranted = false;
            alert("La App necesita permisos de micrófono para usar la voz.");
          }
        }, {
          key: "startListening",
          value: function startListening() {
            var _this8 = this;

            if (!this.permissionGranted) {
              this.getPermission();
              return;
            }

            var options = {
              language: 'es-MX'
            };
            this.isRecording = true; // Start the recognition process

            this.speechRecognition.startListening(options).subscribe(function (matches) {
              _this8.matches = matches;

              _this8.sendMessage(_this8.matches[0]);

              _this8.isRecording = false;

              _this8.cd.detectChanges();
            });
          }
        }, {
          key: "stopListening",
          value: function stopListening() {
            var _this9 = this;

            // Stop the recognition process (iOS only)
            this.speechRecognition.stopListening().then(function () {
              _this9.isRecording = false;
            });
          }
        }, {
          key: "isIos",
          value: function isIos() {
            return this.plt.is('ios');
          }
        }, {
          key: "sendMessage",
          value: function sendMessage(message) {
            this.chat.sendMessage(message);
            this.cd.detectChanges();
          }
        }, {
          key: "responseonseHandler",
          value: function responseonseHandler(data) {
            console.log(data);

            if (data.length > 0) {
              this.scrollToBottom();

              if (data[0].sentBy == 'user') {
                //Add user question to messages list
                this.messages.push(data[0]); //Add fake messages with gif typing...

                this.messages.push(new _models_message_model__WEBPACK_IMPORTED_MODULE_4__["Message"]("", "bot", true));
              }

              if (data[0].sentBy == 'bot' && this.messages.length > 0) {
                //Replace placeholder (gif) with bot  responseonse
                this.messages[this.messages.length - 1] = data[0]; //And now TTS

                this.tts.speak({
                  text: data[0].content,
                  locale: 'es-MX'
                }).then(function () {
                  return console.log('Success');
                })["catch"](function (reason) {
                  return console.log(reason);
                }); //execute action

                this.doAction(data[0]);
              }
            }

            this.cd.detectChanges();
          }
        }, {
          key: "send",
          value: function send() {
            var _this10 = this;

            if (this.input != '') {
              this.sendMessage(this.input);
              this.input = '';
              setTimeout(function () {
                _this10.scrollToBottom();
              }, 10);
            }
          }
        }, {
          key: "scrollToBottom",
          value: function scrollToBottom() {
            this.content.scrollToBottom(300); //300 for animate the scroll effect.
          }
        }, {
          key: "doAction",
          value: function doAction(message) {
            var _this11 = this;

            if (message.action != "" && message.action != "input.unknown") setTimeout(function () {
              _this11.navCtrl.navigateRoot(["/home"]); // this.navCtrl.navigateRoot(["/"+message.action]);

            }, 2000);
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
        }, {
          type: _services_chat_service__WEBPACK_IMPORTED_MODULE_5__["ChatService"]
        }, {
          type: _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_7__["SpeechRecognition"]
        }, {
          type: _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_6__["TextToSpeech"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_8__["Storage"]
        }];
      };

      HomePage.propDecorators = {
        content: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['chatBody', {
            "static": true
          }]
        }]
      };
      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/pages/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    },

    /***/
    "./src/app/services/chat.service.ts":
    /*!******************************************!*\
      !*** ./src/app/services/chat.service.ts ***!
      \******************************************/

    /*! exports provided: ChatService */

    /***/
    function srcAppServicesChatServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatService", function () {
        return ChatService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var api_ai_javascript_es6_ApiAiClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! api-ai-javascript/es6/ApiAiClient */
      "./node_modules/api-ai-javascript/es6/ApiAiClient.js");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "./node_modules/rxjs/_esm2015/index.js");
      /* harmony import */


      var _models_message_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../models/message.model */
      "./src/app/models/message.model.ts");

      var ChatService = /*#__PURE__*/function () {
        function ChatService() {
          _classCallCheck(this, ChatService);

          //Get API Key
          this.token = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].dialogflow.angularBot;
          this.client = new api_ai_javascript_es6_ApiAiClient__WEBPACK_IMPORTED_MODULE_3__["ApiAiClient"]({
            accessToken: this.token
          });
          this.conversation = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]([]);
        }

        _createClass(ChatService, [{
          key: "setResponseHandler",
          value: function setResponseHandler(responseHandler) {
            this.responseHandler = responseHandler;
          } //Send and receive messages via DialogFlow

        }, {
          key: "sendMessage",
          value: function sendMessage(msg) {
            var _this12 = this;

            var userMessage = new _models_message_model__WEBPACK_IMPORTED_MODULE_5__["Message"](msg, 'user');
            this.update(userMessage);
            return this.client.textRequest(msg).then(function (res) {
              //get text of message
              var speech = res.result.fulfillment.speech; //Create new message

              var botMessage = new _models_message_model__WEBPACK_IMPORTED_MODULE_5__["Message"](speech, 'bot', false, res.result.action);

              _this12.update(botMessage);
            });
          } // Add message to source

        }, {
          key: "update",
          value: function update(msg) {
            console.log(_models_message_model__WEBPACK_IMPORTED_MODULE_5__["Message"]);
            this.conversation.next([msg]);
          }
        }]);

        return ChatService;
      }();

      ChatService.ctorParameters = function () {
        return [];
      };

      ChatService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ChatService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-home-home-module-es5.js.map