(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-profile-profile-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html":
    /*!***************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesProfileProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-header titulo=\"Perfil del cuidador\"></app-header>\n\n\n<ion-content class=\"speaker-detail\">\n\n    <div class=\"speaker-background\">\n        <img [src]=\"user.picture\" [alt]=\"user.name\">\n        <h2>{{user.name}}</h2>\n    </div>\n\n\n    <ion-toolbar>\n        <ion-item>\n            <ion-segment value=\"1\" (ionChange)=\"segmentChanged($event)\" color=\"primary\">\n                <ion-segment-button value=\"1\">\n                    <ion-label>Generales</ion-label>\n                </ion-segment-button>\n                <ion-segment-button value=\"2\">\n                    <ion-label>Evolución</ion-label>\n                </ion-segment-button>\n            </ion-segment>\n        </ion-item>\n\n    </ion-toolbar>\n\n    <div class=\"contenido\" *ngIf=\"segment\">\n        <ion-list>\n            <ion-item>\n                <ion-input> {{user.name}}</ion-input>\n            </ion-item>\n            <ion-item>\n                <ion-input type=\"email\">correo@correo.com</ion-input>\n            </ion-item>\n            <ion-item>\n                <ion-input>********</ion-input>\n            </ion-item>\n            <ion-item>\n                <ion-label>Género</ion-label>\n                <ion-select placeholder=\"Selecciona\">\n                    <ion-select-option value=\"f\">Femenino</ion-select-option>\n                    <ion-select-option value=\"m\">Masculino</ion-select-option>\n                </ion-select>\n            </ion-item>\n            <ion-item>\n                <ion-label position=\"floating\">DD/MM/YYYY</ion-label>\n                <ion-datetime displayFormat=\"DD/MM/YYYY\" min=\"1920-01-01\" max=\"2000-01-01\"></ion-datetime>\n            </ion-item>\n            <ion-item>\n                <ion-label>Cuidador principal</ion-label>\n                <ion-select placeholder=\"Selecciona\">\n                    <ion-select-option value=\"true\">Si</ion-select-option>\n                    <ion-select-option value=\"false\">No</ion-select-option>\n                </ion-select>\n            </ion-item>\n            <ion-item>\n                <ion-label>Tiempo de cuidador</ion-label>\n                <ion-select placeholder=\"Selecciona\">\n                    <ion-select-option value=\"1\">Menos de 1 año</ion-select-option>\n                    <ion-select-option value=\"2\">1 a 3 años</ion-select-option>\n                    <ion-select-option value=\"3\">Más de 3 años</ion-select-option>\n                </ion-select>\n            </ion-item>\n            <ion-item>\n                <ion-label>La persona cuidada es mi:</ion-label>\n                <ion-select placeholder=\"Selecciona\">\n                    <ion-select-option value=\"1\">Pareja</ion-select-option>\n                    <ion-select-option value=\"2\">Papá/Mamá</ion-select-option>\n                    <ion-select-option value=\"3\">Abuelo(a)</ion-select-option>\n                    <ion-select-option value=\"4\">Otro familiar</ion-select-option>\n                    <ion-select-option value=\"5\">Amigo(a)</ion-select-option>\n                </ion-select>\n            </ion-item>\n            <ion-item>\n                <ion-button slot=\"end\" expand=\"block\" shape=\"round\" color=\"primary\">Guardar</ion-button>\n            </ion-item>\n        </ion-list>\n    </div>\n\n    <div class=\"contenido\" *ngIf=\"!segment\">\n        <ion-list-header color=\"light\"></ion-list-header>\n        <ion-card class=\"welcome-card\">\n            <ion-card-header>\n                <ion-card-subtitle>Nivel de Sobrecarga:</ion-card-subtitle>\n                <ion-card-title>Leve</ion-card-title>\n            </ion-card-header>\n            <ion-card-content>\n                <img src=\"../../assets/img/sobrecarga.png\">\n            </ion-card-content>\n        </ion-card>\n        <ion-card class=\"welcome-card\">\n            <ion-card-header>\n                <ion-card-subtitle>Nivel de Ansiedad:</ion-card-subtitle>\n                <ion-card-title>Moderada</ion-card-title>\n            </ion-card-header>\n            <ion-card-content>\n                <img src=\"../../assets/img/ansiedad.png\">\n            </ion-card-content>\n        </ion-card>\n        <ion-card class=\"welcome-card\">\n            <ion-card-header>\n                <ion-card-subtitle>Nivel de Depresión:</ion-card-subtitle>\n                <ion-card-title>Moderada</ion-card-title>\n            </ion-card-header>\n            <ion-card-content>\n                <img src=\"../../assets/img/depresion.png\">\n            </ion-card-content>\n        </ion-card>\n    </div>\n\n\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/profile/profile-routing.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/profile/profile-routing.module.ts ***!
      \*********************************************************/

    /*! exports provided: ProfilePageRoutingModule */

    /***/
    function srcAppPagesProfileProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function () {
        return ProfilePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./profile.page */
      "./src/app/pages/profile/profile.page.ts");

      var routes = [{
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
      }];

      var ProfilePageRoutingModule = function ProfilePageRoutingModule() {
        _classCallCheck(this, ProfilePageRoutingModule);
      };

      ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ProfilePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/profile/profile.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/pages/profile/profile.module.ts ***!
      \*************************************************/

    /*! exports provided: ProfilePageModule */

    /***/
    function srcAppPagesProfileProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
        return ProfilePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./profile-routing.module */
      "./src/app/pages/profile/profile-routing.module.ts");
      /* harmony import */


      var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./profile.page */
      "./src/app/pages/profile/profile.page.ts");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components/components.module */
      "./src/app/components/components.module.ts");

      var ProfilePageModule = function ProfilePageModule() {
        _classCallCheck(this, ProfilePageModule);
      };

      ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
      })], ProfilePageModule);
      /***/
    },

    /***/
    "./src/app/pages/profile/profile.page.scss":
    /*!*************************************************!*\
      !*** ./src/app/pages/profile/profile.page.scss ***!
      \*************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesProfileProfilePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "/*\n * Speaker Background\n */\nion-toolbar {\n  position: absolute;\n  top: 1;\n  left: 0;\n  right: 0;\n  --background: transparent;\n  --color: white;\n}\nion-toolbar ion-button,\nion-toolbar ion-back-button,\nion-toolbar ion-menu-button {\n  --color: white;\n}\n.speaker-background {\n  position: relative;\n  display: flex;\n  padding-top: var(--ion-safe-area-top);\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n  height: calc(150px + var(--ion-safe-area-top));\n  background: center/cover url(/assets/img/user-background.png) no-repeat;\n}\n.speaker-background img {\n  width: 70px;\n  border-radius: 50%;\n  margin-top: calc(-1 * var(--ion-safe-area-top));\n}\n.speaker-background h2 {\n  position: absolute;\n  bottom: 10px;\n  color: black;\n}\n.md .speaker-background {\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n}\n.ios .speaker-background {\n  box-shadow: rgba(0, 0, 0, 0.12) 0px 4px 16px;\n}\n/*\n   * Speaker Details\n   */\n.speaker-detail p {\n  margin-left: 6px;\n  margin-right: 6px;\n}\n.speaker-detail hr {\n  margin-top: 20px;\n  margin-bottom: 20px;\n  background: var(--ion-color-step-150, #d7d8da);\n}\n.contenido {\n  margin-top: 45px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7RUFBQTtBQUlBO0VBQ0ksa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFBSjtBQUdBOzs7RUFHSSxjQUFBO0FBQUo7QUFHQTtFQUNJLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHFDQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0EsOENBQUE7RUFDQSx1RUFBQTtBQUFKO0FBR0E7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0FBQTtBQUFKO0FBR0E7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQUo7QUFHQTtFQUNJLHlIQUFBO0FBQUo7QUFHQTtFQUNJLDRDQUFBO0FBQUo7QUFJQTs7SUFBQTtBQUlBO0VBQ0ksZ0JBQUE7RUFDQSxpQkFBQTtBQUZKO0FBS0E7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsOENBQUE7QUFGSjtBQUtBO0VBQ0ksZ0JBQUE7QUFGSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiBTcGVha2VyIEJhY2tncm91bmRcclxuICovXHJcblxyXG5pb24tdG9vbGJhciB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDE7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbmlvbi10b29sYmFyIGlvbi1idXR0b24sXHJcbmlvbi10b29sYmFyIGlvbi1iYWNrLWJ1dHRvbixcclxuaW9uLXRvb2xiYXIgaW9uLW1lbnUtYnV0dG9uIHtcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uc3BlYWtlci1iYWNrZ3JvdW5kIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBwYWRkaW5nLXRvcDogdmFyKC0taW9uLXNhZmUtYXJlYS10b3ApO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGhlaWdodDogY2FsYygxNTBweCArIHZhcigtLWlvbi1zYWZlLWFyZWEtdG9wKSk7XHJcbiAgICBiYWNrZ3JvdW5kOiBjZW50ZXIgLyBjb3ZlciB1cmwoL2Fzc2V0cy9pbWcvdXNlci1iYWNrZ3JvdW5kLnBuZykgbm8tcmVwZWF0O1xyXG59XHJcblxyXG4uc3BlYWtlci1iYWNrZ3JvdW5kIGltZyB7XHJcbiAgICB3aWR0aDogNzBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIG1hcmdpbi10b3A6IGNhbGMoLTEgKiB2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCkpO1xyXG59XHJcblxyXG4uc3BlYWtlci1iYWNrZ3JvdW5kIGgyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMTBweDtcclxuICAgIGNvbG9yOiByZ2IoMCwgMCwgMCk7XHJcbn1cclxuXHJcbi5tZCAuc3BlYWtlci1iYWNrZ3JvdW5kIHtcclxuICAgIGJveC1zaGFkb3c6IHJnYmEoMCwgMCwgMCwgMC4yKSAwcHggM3B4IDFweCAtMnB4LCByZ2JhKDAsIDAsIDAsIDAuMTQpIDBweCAycHggMnB4IDBweCwgcmdiYSgwLCAwLCAwLCAwLjEyKSAwcHggMXB4IDVweCAwcHg7XHJcbn1cclxuXHJcbi5pb3MgLnNwZWFrZXItYmFja2dyb3VuZCB7XHJcbiAgICBib3gtc2hhZG93OiByZ2JhKDAsIDAsIDAsIDAuMTIpIDBweCA0cHggMTZweDtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAgICogU3BlYWtlciBEZXRhaWxzXHJcbiAgICovXHJcblxyXG4uc3BlYWtlci1kZXRhaWwgcCB7XHJcbiAgICBtYXJnaW4tbGVmdDogNnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA2cHg7XHJcbn1cclxuXHJcbi5zcGVha2VyLWRldGFpbCBociB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XHJcbn1cclxuXHJcbi5jb250ZW5pZG8ge1xyXG4gICAgbWFyZ2luLXRvcDogNDVweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/profile/profile.page.ts":
    /*!***********************************************!*\
      !*** ./src/app/pages/profile/profile.page.ts ***!
      \***********************************************/

    /*! exports provided: ProfilePage */

    /***/
    function srcAppPagesProfileProfilePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
        return ProfilePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var src_app_models_user_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/models/user.model */
      "./src/app/models/user.model.ts");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");

      var ProfilePage = /*#__PURE__*/function () {
        // @ViewChild('barCanvas') barCanvas: ElementRef;
        // private barChart: Chart;
        // bars: Chart;
        // colorArray: any;
        function ProfilePage(storage) {
          var _this = this;

          _classCallCheck(this, ProfilePage);

          this.storage = storage;
          this.user = new src_app_models_user_model__WEBPACK_IMPORTED_MODULE_2__["User"]();
          this.segment = true;
          this.storage.get('usuario').then(function (val) {
            _this.user = val;
          });
        }

        _createClass(ProfilePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.cambiarSegment(1);
          }
        }, {
          key: "segmentChanged",
          value: function segmentChanged(event) {
            var valorSegmento = event.detail.value;
            this.cambiarSegment(valorSegmento);
          }
        }, {
          key: "cambiarSegment",
          value: function cambiarSegment(valorSegmento) {
            if (Number(valorSegmento) === 1) {
              this.segment = true;
            } else {
              this.segment = false;
            }
          }
        }]);

        return ProfilePage;
      }();

      ProfilePage.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]
        }];
      };

      ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-profile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./profile.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./profile.page.scss */
        "./src/app/pages/profile/profile.page.scss"))["default"]]
      })], ProfilePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-profile-profile-module-es5.js.map